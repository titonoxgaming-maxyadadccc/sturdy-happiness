# TITONOX PLAYER 1.5.1 - Part 3 stability audit

## Status
Static source audit only. The project was NOT compiled and NOT run on a device in this environment (no Android SDK, no network access to download Gradle). A real build on GitHub Actions or Android Studio is still required.

## Compile-blocking errors fixed (confirmed by real GitHub Actions compiler output earlier)
- innertube `Discovery.kt`: nullable `titleRun.text` -> `titleRun?.text`; explicit `buildList<Innertube.DiscoveryEntry>`; songs without a videoId are skipped instead of crashing de-duplication.
- `Player.kt`: missing `fillMaxSize` import.
- `PlayerScaffold.kt`: `glassBackdrop` is now `LayerBackdrop` (required by `layerBackdrop(...)`).
- `DiscoveryScreens.kt`: missing `forcePlayFromBeginning` import.

## Found during this audit
- `Controls.kt` (Part 1): `R` was used but `com.github.musicyou.R` was never imported (real compiler error on GitHub Actions); import added.
- `EffectsBottomSheet.kt` (Part 1): `ModalBottomSheet` is an experimental Material3 API; added `@OptIn(ExperimentalMaterial3Api::class)`.
- `AppearanceSettings.kt` (Part 2): `horizontalScroll` was imported from the wrong package (`foundation.layout`); corrected to `androidx.compose.foundation.horizontalScroll`.

## Stability / performance
- Album-art accent sampling now has a small in-memory cache, so the mini player, full player, artist page and playlist page do not download and decode the same artwork repeatedly.
- Local device music is now sorted in Kotlin instead of passing a raw `COLLATE NOCASE` string to MediaStore (some Android versions reject unusual sort strings, which would have shown an empty library).

## GitHub readiness
- `.github/workflows/build-apk.yml`: uses the platform package that actually exists (`platforms;android-37.2`), uploads a `build-log` artifact, and prints compiler errors on failure.
- `.gitignore`: now also excludes `**/build/`, APK/AAB files, keystores and logs.
- Version bumped to 1.5.1 (versionCode 23).
- Secret scan: no keystores, tokens or private keys found. The `AIza...` string in innertube is the public YouTube Music web client key used by the upstream project, not a private credential.

## Checks that did run (static scripts)
All Kotlin brackets balanced; every `R.*` reference and every `@resource` reference resolves; manifest classes exist; project imports resolve; no unknown `libs.*` aliases; resource XML parses; no duplicate names, unescaped apostrophes or non-positional multi-argument format strings in any `strings.xml`.

## Known limitations (not changed)
- Local/offline tracks currently show no cover art (no embedded-art extraction).
- Local files pass through the shared audio cache layer, so playing them also fills the app cache; harmless, but uses extra storage until evicted.
- Crossfade, equalizer, bass boost and reverb need a physical device test; effects depend on device audio-effect support.
- Search category slide transitions are not implemented (see Part 2 notes).
- YouTube Music items remain online streams; the private download flow only copies audio files already on the device.

## Part 4 - Square comparison, Radio crash, bar, effects, lyrics (1.5.2)
### Crash fixed
- Radio tab closed the app: every mood/genre tile on YouTube Music shares the same `browseId` (they differ by `params`), and the grid used `browseId` as its lazy key, so Compose threw "Key was already used". The explicit keys were removed from every list in `DiscoveryScreens.kt`, and the mood grid height now includes the row spacing (the last row used to be clipped).

### Bottom bar copied from Square
- `BottomNavigation.kt` now follows Square's bar: the same `LiquidBottomTabs` capsule, tab order Home, New, Radio, Library, Search, 61dp row, 26dp glyphs, 9sp bold labels, Square's glass film (white 12% dark / 45% light) and puck tint, lens depth 20dp, 16dp side margin. Filled icon for the selected tab. The old long-press tab reordering was removed to match Square.
- Deliberate difference: a dark base sits under the film so labels stay readable on phones without blur (Android 11 and older) or while the glass is frozen during scrolling. The text bleeding through the bar in the screenshot came from the previous 22% surface tint.

### Effects screen redesigned
- Opens fully expanded, groups in rounded cards, presets scroll sideways on one line (no more "Fo/lk"), equalizer bands are compact rows (frequency, slider, dB), plus Reset and Flat actions. Same engine calls as before.

### Lyrics
- New synced-lyrics source: LrcLib (matched on artist, title and duration), with KuGou kept as fallback.
- Square-style line renderer: current line large and accent coloured, neighbours fade, shrink and (Android 12+) blur with distance, smooth transitions, tap a line to seek.
- Optional translation under each line (Translate to English / Hindi from the lyrics menu), using the same keyless endpoint Square uses.

### Square features NOT ported (and why)
- Spotify account, Connect, friends, credits: excluded by request.
- Word-by-word lyrics: needs word-timed data (TTML / lossless.wtf); line-level only here.
- Karaoke (vocal removal), Bungee time-stretch, true reverb DSP: native C++ audio code that cannot be built or tested here.
- Music-video mode, Picture-in-Picture, looping canvas video: need video stream resolution and a Media3 video/PiP lifecycle.
- Managed downloads of streamed YouTube songs, offline-only mode, automatic downloads: need a download manager and a local stream resolver.
- Listening-history page and Square's 12-language picker.
