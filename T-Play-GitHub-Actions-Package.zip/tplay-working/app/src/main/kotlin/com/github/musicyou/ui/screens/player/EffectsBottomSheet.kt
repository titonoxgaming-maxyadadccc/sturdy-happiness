package com.github.musicyou.ui.screens.player

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.github.musicyou.LocalPlayerServiceBinder
import com.github.musicyou.R
import com.github.musicyou.utils.audioEffectsEnabledKey
import com.github.musicyou.utils.bassBoostKey
import com.github.musicyou.utils.playbackPitchKey
import com.github.musicyou.utils.playbackSpeedKey
import com.github.musicyou.utils.rememberPreference
import com.github.musicyou.utils.reverbLevelKey

/**
 * The audio-effects sheet. It opens fully expanded (no half-height clipping),
 * every group lives in its own rounded card, preset chips scroll sideways on a
 * single line instead of wrapping, and the equalizer bands are compact rows
 * (frequency, slider, level) so the whole panel scrolls as one page.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EffectsBottomSheet(onDismiss: () -> Unit) {
    val binder = LocalPlayerServiceBinder.current
    var effectsEnabled by rememberPreference(audioEffectsEnabledKey, true)
    var speed by rememberPreference(playbackSpeedKey, 1f)
    var pitch by rememberPreference(playbackPitchKey, 1f)
    var bass by rememberPreference(bassBoostKey, 0)
    var reverb by rememberPreference(reverbLevelKey, 0)

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text(
                    stringResource(R.string.effects),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { speed = 1f; pitch = 1f; bass = 0; reverb = 0; effectsEnabled = true }) {
                    Text("Reset")
                }
            }

            EffectsCard {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                        Text(stringResource(R.string.effects_enabled), style = MaterialTheme.typography.titleMedium)
                        Text(
                            stringResource(R.string.audio_effects_device_note),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = effectsEnabled, onCheckedChange = { effectsEnabled = it })
                }
            }

            EffectsCard {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PresetChip(
                        text = stringResource(R.string.original),
                        selected = speed == 1f && pitch == 1f && bass == 0 && reverb == 0,
                    ) { speed = 1f; pitch = 1f; bass = 0; reverb = 0 }
                    PresetChip(
                        text = stringResource(R.string.slowed_reverb),
                        selected = speed == 0.85f && pitch == 1f && bass == 18 && reverb == 55,
                    ) { speed = 0.85f; pitch = 1f; bass = 18; reverb = 55; effectsEnabled = true }
                    PresetChip(
                        text = stringResource(R.string.speed_up),
                        selected = speed == 1.25f && pitch == 1f && bass == 10 && reverb == 0,
                    ) { speed = 1.25f; pitch = 1f; bass = 10; reverb = 0; effectsEnabled = true }
                }
                EffectSlider("Speed", "%.2f×".format(speed), speed, 0.5f..2f) { speed = it }
                EffectSlider("Pitch", "%.2f×".format(pitch), pitch, 0.7f..1.3f) { pitch = it }
                EffectSlider(stringResource(R.string.bass_boost), "$bass%", bass.toFloat(), 0f..100f) { bass = it.toInt() }
                EffectSlider(stringResource(R.string.reverb), "$reverb%", reverb.toFloat(), 0f..100f) { reverb = it.toInt() }
            }

            val bandCount = binder?.equalizerBandCount() ?: 0
            val bandRange = binder?.equalizerBandRange()
            val bandLevels = remember(binder, bandCount) {
                mutableStateListOf<Int>().apply {
                    repeat(bandCount) { index -> add(binder?.equalizerBandLevel(index) ?: 0) }
                }
            }

            EffectsCard {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Equalizer",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    if (bandCount > 0 && bandRange != null) {
                        TextButton(onClick = {
                            repeat(bandCount) { band ->
                                bandLevels[band] = 0
                                binder?.setEqualizerBandLevel(band, 0)
                            }
                        }) { Text("Flat") }
                    }
                }
                if (bandCount > 0 && bandRange != null) {
                    val presets = remember(binder) { binder?.equalizerPresetNames().orEmpty() }
                    if (presets.isNotEmpty()) {
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            presets.forEachIndexed { index, preset ->
                                PresetChip(text = preset, selected = false) {
                                    binder?.applyEqualizerPreset(index)
                                    repeat(bandCount) { band -> bandLevels[band] = binder?.equalizerBandLevel(band) ?: 0 }
                                }
                            }
                        }
                    }
                    val levelRange = bandRange.first.toFloat()..bandRange.last.toFloat()
                    repeat(bandCount) { index ->
                        val frequencyMilliHz = binder?.equalizerBandFrequency(index) ?: 0
                        val frequencyHz = frequencyMilliHz / 1000
                        val frequencyLabel = if (frequencyHz >= 1000) "${frequencyHz / 1000} kHz" else "$frequencyHz Hz"
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            Text(
                                frequencyLabel,
                                modifier = Modifier.width(64.dp),
                                style = MaterialTheme.typography.labelLarge,
                                maxLines = 1
                            )
                            Slider(
                                value = bandLevels[index].toFloat().coerceIn(levelRange),
                                onValueChange = { level ->
                                    bandLevels[index] = level.toInt()
                                    binder?.setEqualizerBandLevel(index, level.toInt())
                                },
                                valueRange = levelRange,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                "${"%.1f".format(bandLevels[index] / 100f)} dB",
                                modifier = Modifier.width(64.dp),
                                textAlign = TextAlign.End,
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1
                            )
                        }
                    }
                } else {
                    Text(
                        "Built-in equalizer is not available on this device. You can still use bass, reverb, speed and pitch controls.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun EffectsCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = content
        )
    }
}

@Composable
private fun PresetChip(text: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(text, maxLines = 1, softWrap = false) }
    )
}

@Composable
private fun EffectSlider(
    title: String,
    valueLabel: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
            Text(valueLabel, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        }
        Slider(value = value.coerceIn(range), onValueChange = onValueChange, valueRange = range)
    }
}
