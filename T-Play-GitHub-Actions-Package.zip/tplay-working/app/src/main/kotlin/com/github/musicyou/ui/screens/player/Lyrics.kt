package com.github.musicyou.ui.screens.player

import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Fullscreen
import androidx.compose.material.icons.outlined.FullscreenExit
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Translate
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.C
import androidx.media3.common.MediaMetadata
import com.github.innertube.Innertube
import com.github.innertube.requests.lyrics
import com.github.kugou.KuGou
import com.github.musicyou.LocalPlayerServiceBinder
import com.github.musicyou.R
import com.github.musicyou.database
import com.github.musicyou.models.LocalMenuState
import com.github.musicyou.models.Lyrics
import com.github.musicyou.ui.components.Menu
import com.github.musicyou.ui.components.MenuEntry
import com.github.musicyou.ui.components.TextFieldDialog
import com.github.musicyou.ui.components.TextPlaceholder
import com.github.musicyou.ui.styling.Dimensions
import com.github.musicyou.ui.styling.onOverlay
import com.github.musicyou.utils.LrcLib
import com.github.musicyou.utils.LyricsTranslate
import com.github.musicyou.utils.SynchronizedLyrics
import com.github.musicyou.utils.isLandscape
import com.github.musicyou.utils.isShowingSynchronizedLyricsKey
import com.github.musicyou.utils.lyricsTranslationTargetKey
import com.github.musicyou.utils.rememberPreference
import com.github.musicyou.utils.toast
import com.github.musicyou.utils.verticalFadingEdge
import com.valentinilk.shimmer.shimmer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.time.Duration.Companion.milliseconds

@Composable
fun Lyrics(
    mediaId: String,
    isDisplayed: Boolean,
    onDismiss: () -> Unit,
    size: Dp,
    mediaMetadataProvider: () -> MediaMetadata,
    durationProvider: () -> Long,
    ensureSongInserted: () -> Unit,
    fullScreenLyrics: Boolean,
    toggleFullScreenLyrics: () -> Unit
) {
    AnimatedVisibility(
        visible = isDisplayed,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        val context = LocalContext.current
        val menuState = LocalMenuState.current
        val currentView = LocalView.current

        var isShowingSynchronizedLyrics by rememberPreference(isShowingSynchronizedLyricsKey, true)
        var translationTarget by rememberPreference(lyricsTranslationTargetKey, "")

        var isEditing by remember(mediaId, isShowingSynchronizedLyrics) {
            mutableStateOf(false)
        }

        var lyrics by remember {
            mutableStateOf<Lyrics?>(null)
        }

        val text = if (isShowingSynchronizedLyrics) lyrics?.synced else lyrics?.fixed

        var isError by remember(mediaId, isShowingSynchronizedLyrics) {
            mutableStateOf(false)
        }

        LaunchedEffect(mediaId, isShowingSynchronizedLyrics) {
            withContext(Dispatchers.IO) {
                database.lyrics(mediaId).collect {
                    if (isShowingSynchronizedLyrics && it?.synced == null) {
                        val mediaMetadata = mediaMetadataProvider()
                        var duration = withContext(Dispatchers.Main) {
                            durationProvider()
                        }

                        while (duration == C.TIME_UNSET) {
                            delay(duration = 100.milliseconds)
                            duration = withContext(Dispatchers.Main) {
                                durationProvider()
                            }
                        }

                        val lrcLibLyrics = LrcLib.syncedLyrics(
                            artist = mediaMetadata.artist?.toString() ?: "",
                            title = mediaMetadata.title?.toString() ?: "",
                            durationSeconds = duration / 1000
                        )

                        if (lrcLibLyrics != null) {
                            database.upsert(
                                Lyrics(
                                    songId = mediaId,
                                    fixed = it?.fixed,
                                    synced = lrcLibLyrics
                                )
                            )
                        } else {
                            KuGou.lyrics(
                                artist = mediaMetadata.artist?.toString() ?: "",
                                title = mediaMetadata.title?.toString() ?: "",
                                duration = duration / 1000
                            )?.onSuccess { syncedLyrics ->
                                database.upsert(
                                    Lyrics(
                                        songId = mediaId,
                                        fixed = it?.fixed,
                                        synced = syncedLyrics?.value ?: ""
                                    )
                                )
                            }?.onFailure {
                                isError = true
                            }
                        }
                    } else if (!isShowingSynchronizedLyrics && it?.fixed == null) {
                        Innertube.lyrics(videoId = mediaId)?.onSuccess { fixedLyrics ->
                            database.upsert(
                                Lyrics(
                                    songId = mediaId,
                                    fixed = fixedLyrics ?: "",
                                    synced = it?.synced
                                )
                            )
                        }?.onFailure {
                            isError = true
                        }
                    } else {
                        lyrics = it
                    }
                }
            }
        }

        if (isEditing) {
            TextFieldDialog(
                title = stringResource(id = R.string.edit_lyrics),
                hintText = stringResource(id = R.string.enter_lyrics),
                initialTextInput = text ?: "",
                singleLine = false,
                maxLines = 10,
                isTextInputValid = { true },
                onDismiss = { isEditing = false },
                onDone = {
                    database.query {
                        ensureSongInserted()
                        database.upsert(
                            Lyrics(
                                songId = mediaId,
                                fixed = if (isShowingSynchronizedLyrics) lyrics?.fixed else it,
                                synced = if (isShowingSynchronizedLyrics) it else lyrics?.synced,
                            )
                        )
                    }
                }
            )
        }

        if (isShowingSynchronizedLyrics) {
            DisposableEffect(Unit) {
                currentView.keepScreenOn = true
                onDispose {
                    currentView.keepScreenOn = false
                }
            }
        }

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .clickable(onClick = onDismiss)
                .fillMaxSize()
                .background(Color.Black.copy(0.8f))
        ) {
            AnimatedVisibility(
                visible = isError && text == null,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Text(
                    text = if (isShowingSynchronizedLyrics) {
                        stringResource(id = R.string.error_fetching_synchronized_lyrics)
                    } else {
                        stringResource(id = R.string.error_fetching_lyrics)
                    },
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .padding(all = 4.dp)
                        .fillMaxWidth()
                )
            }

            AnimatedVisibility(
                visible = text?.let(String::isEmpty) == true,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.Center)
            ) {
                if (isShowingSynchronizedLyrics) {
                    Column(
                        modifier = Modifier.padding(all = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(space = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = stringResource(id = R.string.synchronized_lyrics_not_available),
                            fontSize = 18.sp,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Button(
                            onClick = { isShowingSynchronizedLyrics = false }
                        ) {
                            Text(text = stringResource(id = R.string.show_unsynchronized_lyrics))
                        }
                    }
                } else {
                    Text(
                        text = stringResource(id = R.string.lyrics_not_available),
                        fontSize = 18.sp,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .padding(all = 8.dp)
                            .fillMaxWidth()
                    )
                }
            }

            if (text?.isNotEmpty() == true) {
                if (isShowingSynchronizedLyrics) {
                    val density = LocalDensity.current
                    val player = LocalPlayerServiceBinder.current?.player
                        ?: return@AnimatedVisibility

                    val synchronizedLyrics = remember(text) {
                        SynchronizedLyrics(KuGou.Lyrics(text).sentences) {
                            player.currentPosition + 50
                        }
                    }

                    var translations by remember(synchronizedLyrics, translationTarget) {
                        mutableStateOf<List<String>?>(null)
                    }

                    LaunchedEffect(synchronizedLyrics, translationTarget) {
                        translations = if (translationTarget.isEmpty()) {
                            null
                        } else {
                            LyricsTranslate.lines(
                                texts = synchronizedLyrics.sentences.map { it.second },
                                target = translationTarget
                            )
                        }
                    }

                    val lazyListState = rememberLazyListState(
                        synchronizedLyrics.index,
                        with(density) { size.roundToPx() } / 6)

                    LaunchedEffect(synchronizedLyrics) {
                        val center = with(density) { size.roundToPx() } / 6

                        while (isActive) {
                            delay(duration = 50.milliseconds)
                            if (synchronizedLyrics.update()) {
                                lazyListState.animateScrollToItem(
                                    synchronizedLyrics.index,
                                    center
                                )
                            }
                        }
                    }

                    LazyColumn(
                        state = lazyListState,
                        userScrollEnabled = false,
                        contentPadding = PaddingValues(vertical = size / 2),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.verticalFadingEdge()
                    ) {
                        itemsIndexed(items = synchronizedLyrics.sentences) { index, sentence ->
                            LyricLine(
                                text = sentence.second,
                                translation = translations?.getOrNull(index)?.takeIf { it.isNotBlank() },
                                distance = abs(index - synchronizedLyrics.index),
                                onClick = { player.seekTo(sentence.first) }
                            )
                        }
                    }
                } else {
                    Text(
                        text = text,
                        color = Color.White,
                        fontSize = 20.sp,
                        lineHeight = 30.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .verticalFadingEdge()
                            .verticalScroll(rememberScrollState())
                            .fillMaxWidth()
                            .padding(vertical = size / 4, horizontal = 32.dp)
                    )
                }
            }

            if (text == null && !isError) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.shimmer()
                ) {
                    repeat(4) {
                        TextPlaceholder(
                            modifier = Modifier.alpha(1f - it * 0.2f)
                        )
                    }
                }
            }

            if (!isLandscape) {
                IconButton(
                    onClick = toggleFullScreenLyrics,
                    modifier = Modifier.align(Alignment.BottomStart)
                ) {
                    Icon(
                        imageVector = if (fullScreenLyrics) Icons.Outlined.FullscreenExit else Icons.Outlined.Fullscreen,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onOverlay
                    )
                }
            }

            IconButton(
                onClick = {
                    menuState.display {
                        Menu {
                            MenuEntry(
                                icon = Icons.Outlined.Schedule,
                                text = if (isShowingSynchronizedLyrics) {
                                    stringResource(id = R.string.show_unsynchronized_lyrics)
                                } else {
                                    stringResource(id = R.string.show_synchronized_lyrics)
                                },
                                secondaryText = if (isShowingSynchronizedLyrics) null else {
                                    stringResource(id = R.string.provided_by_kugou)
                                },
                                onClick = {
                                    menuState.hide()
                                    isShowingSynchronizedLyrics =
                                        !isShowingSynchronizedLyrics
                                }
                            )

                            MenuEntry(
                                icon = Icons.Outlined.Translate,
                                text = if (translationTarget == "en") "Hide translation" else "Translate to English",
                                onClick = {
                                    menuState.hide()
                                    translationTarget = if (translationTarget == "en") "" else "en"
                                }
                            )

                            MenuEntry(
                                icon = Icons.Outlined.Translate,
                                text = if (translationTarget == "hi") "Hide translation" else "Translate to Hindi",
                                onClick = {
                                    menuState.hide()
                                    translationTarget = if (translationTarget == "hi") "" else "hi"
                                }
                            )

                            MenuEntry(
                                icon = Icons.Outlined.Edit,
                                text = stringResource(id = R.string.edit_lyrics),
                                onClick = {
                                    menuState.hide()
                                    isEditing = true
                                }
                            )

                            MenuEntry(
                                icon = Icons.Outlined.Search,
                                text = stringResource(id = R.string.search_lyrics_online),
                                onClick = {
                                    menuState.hide()
                                    val mediaMetadata = mediaMetadataProvider()

                                    try {
                                        context.startActivity(
                                            Intent(Intent.ACTION_WEB_SEARCH).apply {
                                                putExtra(
                                                    SearchManager.QUERY,
                                                    "${mediaMetadata.title} ${mediaMetadata.artist} lyrics"
                                                )
                                            }
                                        )
                                    } catch (_: ActivityNotFoundException) {
                                        context.toast("Couldn't find an application to browse the Internet")
                                    }
                                }
                            )

                            MenuEntry(
                                icon = Icons.Outlined.Download,
                                text = stringResource(id = R.string.fetch_lyrics_again),
                                enabled = lyrics != null,
                                onClick = {
                                    menuState.hide()
                                    database.query {
                                        database.upsert(
                                            Lyrics(
                                                songId = mediaId,
                                                fixed = if (isShowingSynchronizedLyrics) lyrics?.fixed else null,
                                                synced = if (isShowingSynchronizedLyrics) null else lyrics?.synced,
                                            )
                                        )
                                    }
                                }
                            )
                        }
                    }
                },
                modifier = Modifier.align(Alignment.BottomEnd)
            ) {
                Icon(
                    imageVector = Icons.Outlined.MoreHoriz,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onOverlay
                )
            }
        }
    }
}

/**
 * One synchronized lyric line. Every line keeps the same size so the list never
 * re-flows while it scrolls; the line being sung is full colour, full size and
 * sharp, and the ones around it fall away in opacity, size and (on Android 12+)
 * a little blur the further they are from it. Tapping a line seeks to it.
 */
@Composable
private fun LyricLine(text: String, translation: String?, distance: Int, onClick: () -> Unit) {
    val active = distance == 0
    val targetAlpha = when (distance) {
        0 -> 1f
        1 -> 0.62f
        2 -> 0.46f
        else -> 0.32f
    }
    val lineAlpha by animateFloatAsState(
        targetValue = targetAlpha,
        animationSpec = tween(durationMillis = 320),
        label = "lyricAlpha"
    )
    val lineScale by animateFloatAsState(
        targetValue = if (active) 1f else 0.9f,
        animationSpec = tween(durationMillis = 320),
        label = "lyricScale"
    )
    val lineColor by animateColorAsState(
        targetValue = if (active) MaterialTheme.colorScheme.primary else Color.White,
        animationSpec = tween(durationMillis = 320),
        label = "lyricColor"
    )
    val blurRadius = (distance.coerceAtMost(3) * 0.9f).dp

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(interactionSource = null, indication = null, onClick = onClick)
            .padding(vertical = 6.dp, horizontal = 28.dp)
            .graphicsLayer {
                scaleX = lineScale
                scaleY = lineScale
                alpha = lineAlpha
            }
            .blur(blurRadius)
    ) {
        Text(
            text = text,
            color = lineColor,
            textAlign = TextAlign.Center,
            fontSize = 24.sp,
            lineHeight = 31.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.SemiBold,
            modifier = Modifier.fillMaxWidth()
        )
        if (translation != null) {
            Text(
                text = translation,
                color = Color.White.copy(alpha = 0.78f),
                textAlign = TextAlign.Center,
                fontSize = 15.sp,
                lineHeight = 20.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 2.dp)
            )
        }
    }
}
