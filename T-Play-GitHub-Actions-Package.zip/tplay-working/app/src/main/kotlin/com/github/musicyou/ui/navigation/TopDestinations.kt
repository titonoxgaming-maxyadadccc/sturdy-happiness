package com.github.musicyou.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Podcasts
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LibraryMusic
import androidx.compose.material.icons.outlined.Podcasts
import androidx.compose.material.icons.outlined.Search
import com.github.musicyou.R

object TopDestinations {
    // Keep the primary dock intentionally short. Songs, Artists, Albums and
    // Playlists are grouped under Library instead of crowding the bottom bar.
    val list = listOf(
        TopDestination(
            route = Routes.Home,
            resourceId = R.string.home,
            unselectedIcon = Icons.Outlined.Home,
            selectedIcon = Icons.Filled.Home
        ),
        TopDestination(
            route = Routes.Library,
            resourceId = R.string.library,
            unselectedIcon = Icons.Outlined.LibraryMusic,
            selectedIcon = Icons.Filled.LibraryMusic
        ),
        TopDestination(
            route = Routes.New,
            resourceId = R.string.new_music,
            unselectedIcon = Icons.Outlined.Explore,
            selectedIcon = Icons.Filled.Explore
        ),
        TopDestination(
            route = Routes.Radio,
            resourceId = R.string.radio,
            unselectedIcon = Icons.Outlined.Podcasts,
            selectedIcon = Icons.Filled.Podcasts
        ),
        TopDestination(
            route = Routes.Search,
            resourceId = R.string.search,
            unselectedIcon = Icons.Outlined.Search,
            selectedIcon = Icons.Filled.Search
        )
    )

    val routes = list.map { it.route }
}
