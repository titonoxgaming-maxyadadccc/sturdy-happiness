package com.github.musicyou.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Time-synced lyrics from LrcLib (https://lrclib.net), the open lyrics database
 * that Square also uses for line-synced lyrics. It matches on artist, title and
 * duration, so it is far less likely than a keyword search to return the lyrics
 * of a different song. Returns an LRC string ("[mm:ss.xx] line"), or null when
 * nothing usable exists or the request fails.
 */
object LrcLib {
    private const val BASE = "https://lrclib.net/api"

    suspend fun syncedLyrics(artist: String, title: String, durationSeconds: Long): String? =
        withContext(Dispatchers.IO) {
            runCatching {
                if (title.isBlank()) return@runCatching null
                val artistParam = URLEncoder.encode(artist.trim(), "UTF-8")
                val titleParam = URLEncoder.encode(title.trim(), "UTF-8")
                val durationParam = if (durationSeconds > 0) "&duration=$durationSeconds" else ""

                val exact = fetch("$BASE/get?artist_name=$artistParam&track_name=$titleParam$durationParam")
                    ?.let { body -> runCatching { JSONObject(body).optString("syncedLyrics") }.getOrNull() }
                    ?.takeIf { isUsable(it) }
                if (exact != null) return@runCatching exact

                val results = fetch("$BASE/search?artist_name=$artistParam&track_name=$titleParam")
                    ?.let { body -> runCatching { JSONArray(body) }.getOrNull() }
                    ?: return@runCatching null

                var best: String? = null
                var bestGap = Long.MAX_VALUE
                for (index in 0 until results.length()) {
                    val item = results.optJSONObject(index) ?: continue
                    val synced = item.optString("syncedLyrics")
                    if (!isUsable(synced)) continue
                    val gap = if (durationSeconds > 0) {
                        kotlin.math.abs(item.optLong("duration", durationSeconds) - durationSeconds)
                    } else 0L
                    if (gap < bestGap) {
                        best = synced
                        bestGap = gap
                    }
                }
                // Accept a search hit only when its length is close to this song's.
                if (best != null && (durationSeconds <= 0 || bestGap <= 5)) best else null
            }.getOrNull()
        }

    private fun isUsable(text: String): Boolean = text.isNotBlank() && text != "null"

    private fun fetch(url: String): String? {
        val connection = URL(url).openConnection() as HttpURLConnection
        return try {
            connection.connectTimeout = 8_000
            connection.readTimeout = 8_000
            connection.setRequestProperty("User-Agent", "TITONOX-PLAYER (Android)")
            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                connection.inputStream.bufferedReader().use { it.readText() }
            } else null
        } finally {
            connection.disconnect()
        }
    }
}
