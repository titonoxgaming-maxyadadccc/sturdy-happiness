package com.github.musicyou.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.Configuration
import android.database.SQLException
import android.graphics.Color
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaDescription
import android.media.MediaMetadata
import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.EnvironmentalReverb
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.support.v4.media.session.MediaSessionCompat
import android.text.format.DateUtils
import androidx.annotation.OptIn
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startForegroundService
import androidx.core.content.getSystemService
import androidx.core.net.toUri
import androidx.core.text.isDigitsOnly
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.Cache
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.NoOpCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.RenderersFactory
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.analytics.PlaybackStats
import androidx.media3.exoplayer.analytics.PlaybackStatsListener
import androidx.media3.exoplayer.audio.AudioRendererEventListener
import androidx.media3.exoplayer.audio.AudioTrackAudioOutputProvider
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink.DefaultAudioProcessorChain
import androidx.media3.exoplayer.audio.MediaCodecAudioRenderer
import androidx.media3.exoplayer.audio.SilenceSkippingAudioProcessor
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.extractor.DefaultExtractorsFactory
import com.github.innertube.Innertube
import com.github.innertube.models.NavigationEndpoint
import com.github.innertube.requests.player
import com.github.innertube.requests.searchPage
import com.github.innertube.utils.from
import com.github.musicyou.MainActivity
import com.github.musicyou.R
import com.github.musicyou.database
import com.github.musicyou.enums.ExoPlayerDiskCacheMaxSize
import com.github.musicyou.models.Event
import com.github.musicyou.models.Format
import com.github.musicyou.models.QueuedMediaItem
import com.github.musicyou.utils.InvincibleService
import com.github.musicyou.utils.RingBuffer
import com.github.musicyou.utils.TimerJob
import com.github.musicyou.utils.YouTubeRadio
import com.github.musicyou.utils.activityPendingIntent
import com.github.musicyou.utils.broadCastPendingIntent
import com.github.musicyou.utils.exoPlayerDiskCacheMaxSizeKey
import com.github.musicyou.utils.findNextMediaItemById
import com.github.musicyou.utils.forcePlayFromBeginning
import com.github.musicyou.utils.forceSeekToNext
import com.github.musicyou.utils.forceSeekToPrevious
import com.github.musicyou.utils.getEnum
import com.github.musicyou.utils.intent
import com.github.musicyou.utils.isAtLeastAndroid13
import com.github.musicyou.utils.isAtLeastAndroid8
import com.github.musicyou.utils.isInvincibilityEnabledKey
import com.github.musicyou.utils.isShowingThumbnailInLockscreenKey
import com.github.musicyou.utils.mediaItems
import com.github.musicyou.utils.persistentQueueKey
import com.github.musicyou.utils.playbackPitchKey
import com.github.musicyou.utils.audioEffectsEnabledKey
import com.github.musicyou.utils.bassBoostKey
import com.github.musicyou.utils.reverbLevelKey
import com.github.musicyou.utils.playbackSpeedKey
import com.github.musicyou.utils.crossfadeEnabledKey
import com.github.musicyou.utils.crossfadeDurationMsKey
import com.github.musicyou.utils.preferences
import com.github.musicyou.utils.queueLoopEnabledKey
import com.github.musicyou.utils.resumePlaybackWhenDeviceConnectedKey
import com.github.musicyou.utils.shouldBePlaying
import com.github.musicyou.utils.skipSilenceKey
import com.github.musicyou.utils.timer
import com.github.musicyou.utils.trackLoopEnabledKey
import com.github.musicyou.utils.volumeNormalizationKey
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.cancellable
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapMerge
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.plus
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt
import kotlin.system.exitProcess
import android.os.Binder as AndroidBinder

@OptIn(UnstableApi::class)
class PlayerService : InvincibleService(), Player.Listener, PlaybackStatsListener.Callback,
    SharedPreferences.OnSharedPreferenceChangeListener {
    private lateinit var mediaSession: MediaSession
    private lateinit var cache: SimpleCache
    private lateinit var player: ExoPlayer
    private var crossfadePlayer: ExoPlayer? = null
    private val crossfadeScope = CoroutineScope(Dispatchers.Main.immediate + SupervisorJob())
    private var crossfadeMonitorJob: Job? = null
    private var crossfadeJob: Job? = null
    private var crossfadeSourceId: String? = null
    private var committingCrossfade = false
    private var crossfadeBaseVolume = 1f
    private var bassBoostEffect: BassBoost? = null
    private var environmentalReverbEffect: EnvironmentalReverb? = null
    private var equalizerEffect: Equalizer? = null
    private var crossfadeBassBoostEffect: BassBoost? = null
    private var crossfadeReverbEffect: EnvironmentalReverb? = null
    private var crossfadeEqualizerEffect: Equalizer? = null

    private val stateBuilder
        get() = PlaybackState.Builder()
            .setActions(
                PlaybackState.ACTION_PLAY
                        or PlaybackState.ACTION_PAUSE
                        or PlaybackState.ACTION_PLAY_PAUSE
                        or PlaybackState.ACTION_STOP
                        or PlaybackState.ACTION_SKIP_TO_PREVIOUS
                        or PlaybackState.ACTION_SKIP_TO_NEXT
                        or PlaybackState.ACTION_SKIP_TO_QUEUE_ITEM
                        or PlaybackState.ACTION_SEEK_TO
                        or PlaybackState.ACTION_REWIND
                        or PlaybackState.ACTION_PLAY_FROM_SEARCH
            )
            .addCustomAction(
                FAVORITE_ACTION,
                "Toggle like",
                if (isLikedState.value) R.drawable.heart else R.drawable.heart_outline
            )

    private val playbackStateMutex = Mutex()

    private val metadataBuilder = MediaMetadata.Builder()

    private var notificationManager: NotificationManager? = null

    private var timerJob: TimerJob? = null
    private var sleepFadeJob: Job? = null
    private var sleepFadeOriginalVolume = 1f

    private var radio: YouTubeRadio? = null

    private lateinit var bitmapProvider: BitmapProvider

    private val coroutineScope = CoroutineScope(Dispatchers.IO) + Job()

    private var volumeNormalizationJob: Job? = null

    private var isPersistentQueueEnabled = false
    private var isShowingThumbnailInLockscreen = true
    override var isInvincibilityEnabled = false

    private var audioManager: AudioManager? = null
    private var audioDeviceCallback: AudioDeviceCallback? = null

    private var loudnessEnhancer: LoudnessEnhancer? = null

    private val binder = Binder()

    private var isNotificationStarted = false

    override val notificationId: Int
        get() = NOTIFICATION_ID

    private lateinit var notificationActionReceiver: NotificationActionReceiver

    private val mediaItemState = MutableStateFlow<MediaItem?>(null)

    @kotlin.OptIn(ExperimentalCoroutinesApi::class)
    private val isLikedState = mediaItemState
        .flatMapMerge { item ->
            item?.mediaId?.let {
                database
                    .likedAt(it)
                    .distinctUntilChanged()
                    .cancellable()
            } ?: flowOf(null)
        }
        .map { it != null }
        .stateIn(
            scope = coroutineScope,
            started = SharingStarted.Eagerly,
            initialValue = false
        )

    override fun onBind(intent: Intent?): AndroidBinder {
        super.onBind(intent)
        return binder
    }

    override fun onCreate() {
        super.onCreate()

        bitmapProvider = BitmapProvider(
            context = applicationContext,
            bitmapSize = (256 * resources.displayMetrics.density).roundToInt(),
            colorProvider = { isSystemInDarkMode ->
                if (isSystemInDarkMode) Color.BLACK else Color.WHITE
            }
        )

        createNotificationChannel()

        preferences.registerOnSharedPreferenceChangeListener(this)

        val preferences = preferences
        isPersistentQueueEnabled = preferences.getBoolean(persistentQueueKey, false)
        isInvincibilityEnabled = preferences.getBoolean(isInvincibilityEnabledKey, false)
        isShowingThumbnailInLockscreen =
            preferences.getBoolean(isShowingThumbnailInLockscreenKey, false)

        val cacheEvictor = when (val size =
            preferences.getEnum(exoPlayerDiskCacheMaxSizeKey, ExoPlayerDiskCacheMaxSize.`2GB`)) {
            ExoPlayerDiskCacheMaxSize.Unlimited -> NoOpCacheEvictor()
            else -> LeastRecentlyUsedCacheEvictor(size.bytes)
        }

        // TODO: Remove in a future release
        val directory = cacheDir.resolve("exoplayer").also { directory ->
            if (directory.exists()) return@also

            directory.mkdir()

            cacheDir.listFiles()?.forEach { file ->
                if (file.isDirectory && file.name.length == 1 && file.name.isDigitsOnly() || file.extension == "uid") {
                    if (!file.renameTo(directory.resolve(file.name))) {
                        file.deleteRecursively()
                    }
                }
            }

            filesDir.resolve("coil").deleteRecursively()
        }
        cache = SimpleCache(directory, cacheEvictor, StandaloneDatabaseProvider(this))

        player = ExoPlayer.Builder(this, createRendersFactory(), createMediaSourceFactory())
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setUsePlatformDiagnostics(false)
            .build()

        createPlaybackEffects()

        player.repeatMode = when {
            preferences.getBoolean(trackLoopEnabledKey, false) -> Player.REPEAT_MODE_ONE
            preferences.getBoolean(queueLoopEnabledKey, false) -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }

        player.skipSilenceEnabled = preferences.getBoolean(skipSilenceKey, false)
        player.setPlaybackParameters(
            PlaybackParameters(
                preferences.getFloat(playbackSpeedKey, 1f).coerceIn(0.5f, 2f),
                preferences.getFloat(playbackPitchKey, 1f).coerceIn(0.7f, 1.3f),
            )
        )
        player.addListener(this)
        player.addAnalyticsListener(PlaybackStatsListener(false, this))

        if (preferences.getBoolean(crossfadeEnabledKey, true)) {
            ensureCrossfadePlayer()
        }
        startCrossfadeMonitor()
        maybeRestorePlayerQueue()

        mediaSession = MediaSession(baseContext, "PlayerService")
        mediaSession.setCallback(SessionCallback(player))
        mediaSession.setPlaybackState(stateBuilder.build())
        mediaSession.isActive = true

        coroutineScope.launch {
            isLikedState
                .onEach { withContext(Dispatchers.Main) { updatePlaybackState() } }
                .collect()
        }

        notificationActionReceiver = NotificationActionReceiver(player)

        val filter = IntentFilter().apply {
            addAction(Action.play.value)
            addAction(Action.pause.value)
            addAction(Action.next.value)
            addAction(Action.previous.value)
        }

        ContextCompat.registerReceiver(
            this,
            notificationActionReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        maybeResumePlaybackWhenDeviceConnected()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!player.shouldBePlaying) {
            broadCastPendingIntent<NotificationDismissReceiver>().send()
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        maybeSavePlayerQueue()

        preferences.unregisterOnSharedPreferenceChangeListener(this)

        crossfadeMonitorJob?.cancel()
        crossfadeJob?.cancel()
        crossfadeScope.coroutineContext[Job]?.cancel()
        runCatching { crossfadePlayer?.pause() }
        runCatching { crossfadePlayer?.stop() }

        player.removeListener(this)
        releasePlaybackEffects()
        runCatching { crossfadePlayer?.release() }
        crossfadePlayer = null
        player.stop()
        player.release()

        unregisterReceiver(notificationActionReceiver)

        mediaSession.isActive = false
        mediaSession.release()
        cache.release()

        loudnessEnhancer?.release()

        super.onDestroy()
    }

    override fun shouldBeInvincible(): Boolean {
        return !player.shouldBePlaying
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        if (bitmapProvider.setDefaultBitmap() && player.currentMediaItem != null) {
            notificationManager?.notify(NOTIFICATION_ID, notification())
        }
        super.onConfigurationChanged(newConfig)
    }

    override fun onPlaybackStatsReady(
        eventTime: AnalyticsListener.EventTime,
        playbackStats: PlaybackStats
    ) {
        val mediaItem =
            eventTime.timeline.getWindow(eventTime.windowIndex, Timeline.Window()).mediaItem

        val totalPlayTimeMs = playbackStats.totalPlayTimeMs

        if (totalPlayTimeMs > 5000) {
            database.query {
                database.incrementTotalPlayTimeMs(mediaItem.mediaId, totalPlayTimeMs)
            }
        }

        if (totalPlayTimeMs > 30000) {
            database.query {
                try {
                    database.insert(
                        Event(
                            songId = mediaItem.mediaId,
                            timestamp = System.currentTimeMillis(),
                            playTime = totalPlayTimeMs
                        )
                    )
                } catch (_: SQLException) {
                }
            }
        }
    }

    override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
        if (!playWhenReady && crossfadeJob?.isActive == true && !committingCrossfade) {
            cancelCrossfade(restoreMainVolume = true)
        }
    }

    override fun onPositionDiscontinuity(
        oldPosition: Player.PositionInfo,
        newPosition: Player.PositionInfo,
        reason: Int
    ) {
        if (reason == Player.DISCONTINUITY_REASON_SEEK &&
            crossfadeJob?.isActive == true &&
            !committingCrossfade
        ) {
            cancelCrossfade(restoreMainVolume = true)
        }
    }

    override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
        if (crossfadeJob?.isActive == true && !committingCrossfade) {
            cancelCrossfade(restoreMainVolume = true)
        }
    }

    override fun onRepeatModeChanged(repeatMode: Int) {
        if (crossfadeJob?.isActive == true && !committingCrossfade) {
            cancelCrossfade(restoreMainVolume = true)
        }
    }

    override fun onTimelineChanged(timeline: Timeline, reason: Int) {
        if (reason == Player.TIMELINE_CHANGE_REASON_PLAYLIST_CHANGED &&
            crossfadeJob?.isActive == true && !committingCrossfade
        ) {
            cancelCrossfade(restoreMainVolume = true)
        }
        if (reason == Player.TIMELINE_CHANGE_REASON_PLAYLIST_CHANGED) {
            updateMediaSessionQueue(timeline)
        }
    }

    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
        if (!committingCrossfade && crossfadeSourceId != null &&
            mediaItem?.mediaId != crossfadeSourceId
        ) {
            cancelCrossfade(restoreMainVolume = true)
        }
        mediaItemState.update { mediaItem }

        maybeRecoverPlaybackError()
        maybeNormalizeVolume()
        maybeProcessRadio()

        if (mediaItem == null) {
            bitmapProvider.listener?.invoke(null)
        } else if (mediaItem.mediaMetadata.artworkUri == bitmapProvider.lastUri) {
            bitmapProvider.listener?.invoke(bitmapProvider.lastBitmap)
        }

        if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO || reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK) {
            updateMediaSessionQueue(player.currentTimeline)
        }
    }

    private fun updateMediaSessionQueue(timeline: Timeline) {
        val builder = MediaDescription.Builder()

        val currentMediaItemIndex = player.currentMediaItemIndex
        val lastIndex = timeline.windowCount - 1
        var startIndex = currentMediaItemIndex - 7
        var endIndex = currentMediaItemIndex + 7

        if (startIndex < 0) endIndex -= startIndex

        if (endIndex > lastIndex) {
            startIndex -= (endIndex - lastIndex)
            endIndex = lastIndex
        }

        startIndex = startIndex.coerceAtLeast(0)

        mediaSession.setQueue(
            List(endIndex - startIndex + 1) { index ->
                val mediaItem = timeline.getWindow(index + startIndex, Timeline.Window()).mediaItem
                MediaSession.QueueItem(
                    builder
                        .setMediaId(mediaItem.mediaId)
                        .setTitle(mediaItem.mediaMetadata.title)
                        .setSubtitle(mediaItem.mediaMetadata.artist)
                        .setIconUri(mediaItem.mediaMetadata.artworkUri)
                        .build(),
                    (index + startIndex).toLong()
                )
            }
        )
    }

    private fun maybeRecoverPlaybackError() {
        if (player.playerError != null) player.prepare()
    }

    private fun maybeProcessRadio() {
        radio?.let { radio ->
            if (player.mediaItemCount - player.currentMediaItemIndex <= 3) {
                coroutineScope.launch(Dispatchers.Main) {
                    player.addMediaItems(radio.process())
                }
            }
        }
    }

    private fun maybeSavePlayerQueue() {
        if (!isPersistentQueueEnabled) return

        val mediaItems = player.currentTimeline.mediaItems
        val mediaItemIndex = player.currentMediaItemIndex
        val mediaItemPosition = player.currentPosition

        mediaItems.mapIndexed { index, mediaItem ->
            QueuedMediaItem(
                mediaItem = mediaItem,
                position = if (index == mediaItemIndex) mediaItemPosition else null
            )
        }.let { queuedMediaItems ->
            database.query {
                database.clearQueue()
                database.insert(queuedMediaItems)
            }
        }
    }

    private fun maybeRestorePlayerQueue() {
        if (!isPersistentQueueEnabled) return

        database.query {
            val queuedSong = database.queue()
            database.clearQueue()

            if (queuedSong.isEmpty()) return@query

            val index = queuedSong.indexOfFirst { it.position != null }.coerceAtLeast(0)

            runBlocking(Dispatchers.Main) {
                player.setMediaItems(
                    queuedSong.map { mediaItem ->
                        mediaItem.mediaItem.buildUpon()
                            .setUri(mediaItem.mediaItem.mediaId)
                            .setCustomCacheKey(mediaItem.mediaItem.mediaId)
                            .build().apply {
                                mediaMetadata.extras?.putBoolean("isFromPersistentQueue", true)
                            }
                    },
                    index,
                    queuedSong[index].position ?: C.TIME_UNSET
                )
                player.prepare()

                isNotificationStarted = true
                startForegroundService(this@PlayerService, intent<PlayerService>())
                startForeground(NOTIFICATION_ID, notification())
            }
        }
    }

    private fun maybeNormalizeVolume() {
        if (!preferences.getBoolean(volumeNormalizationKey, false)) {
            loudnessEnhancer?.enabled = false
            loudnessEnhancer?.release()
            loudnessEnhancer = null
            volumeNormalizationJob?.cancel()
            player.volume = 1f
            return
        }

        if (loudnessEnhancer == null) {
            loudnessEnhancer = LoudnessEnhancer(player.audioSessionId)
        }

        player.currentMediaItem?.mediaId?.let { songId ->
            volumeNormalizationJob?.cancel()
            volumeNormalizationJob = coroutineScope.launch(Dispatchers.Main) {
                database.loudnessDb(songId).cancellable().collectLatest { loudnessDb ->
                    try {
                        loudnessEnhancer?.setTargetGain(-((loudnessDb ?: 0f) * 100).toInt() + 500)
                        loudnessEnhancer?.enabled = true
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    private fun maybeShowSongCoverInLockScreen() {
        val bitmap =
            if (isAtLeastAndroid13 || isShowingThumbnailInLockscreen) bitmapProvider.bitmap else null

        metadataBuilder.putBitmap(MediaMetadata.METADATA_KEY_ART, bitmap)

        if (isAtLeastAndroid13 && player.currentMediaItemIndex == 0) {
            metadataBuilder.putText(
                MediaMetadata.METADATA_KEY_TITLE,
                "${player.mediaMetadata.title} "
            )
        }

        mediaSession.setMetadata(metadataBuilder.build())
    }

    private fun maybeResumePlaybackWhenDeviceConnected() {
        if (preferences.getBoolean(resumePlaybackWhenDeviceConnectedKey, false)) {
            if (audioManager == null) {
                audioManager = getSystemService(AUDIO_SERVICE) as AudioManager?
            }

            audioDeviceCallback = object : AudioDeviceCallback() {
                private fun canPlayMusic(audioDeviceInfo: AudioDeviceInfo): Boolean {
                    if (!audioDeviceInfo.isSink) return false

                    return audioDeviceInfo.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                            audioDeviceInfo.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                            audioDeviceInfo.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                            (isAtLeastAndroid8 && audioDeviceInfo.type == AudioDeviceInfo.TYPE_USB_HEADSET)
                }

                override fun onAudioDevicesAdded(addedDevices: Array<AudioDeviceInfo>) {
                    if (!player.isPlaying && addedDevices.any(::canPlayMusic)) {
                        player.play()
                    }
                }

                override fun onAudioDevicesRemoved(removedDevices: Array<AudioDeviceInfo>) = Unit
            }

            audioManager?.registerAudioDeviceCallback(audioDeviceCallback, handler)

        } else {
            audioManager?.unregisterAudioDeviceCallback(audioDeviceCallback)
            audioDeviceCallback = null
        }
    }

    private fun createPlaybackEffects() {
        val sessionId = player.audioSessionId
        if (sessionId <= 0) return
        if (bassBoostEffect == null) runCatching { BassBoost(0, sessionId) }.onSuccess { bassBoostEffect = it }
        if (environmentalReverbEffect == null) runCatching { EnvironmentalReverb(0, sessionId) }.onSuccess { environmentalReverbEffect = it }
        if (equalizerEffect == null) runCatching { Equalizer(0, sessionId) }.onSuccess { equalizerEffect = it }
        applyPlaybackEffects()
    }

    private fun createCrossfadePlaybackEffects() {
        val sessionId = crossfadePlayer?.audioSessionId ?: return
        if (sessionId <= 0) return
        if (crossfadeBassBoostEffect == null) {
            runCatching { BassBoost(0, sessionId) }.onSuccess { crossfadeBassBoostEffect = it }
        }
        if (crossfadeReverbEffect == null) {
            runCatching { EnvironmentalReverb(0, sessionId) }.onSuccess { crossfadeReverbEffect = it }
        }
        if (crossfadeEqualizerEffect == null) {
            runCatching { Equalizer(0, sessionId) }.onSuccess { crossfadeEqualizerEffect = it }
        }
        applyPlaybackEffects()
    }

    private fun applyPlaybackEffects() {
        val enabled = preferences.getBoolean(audioEffectsEnabledKey, true)
        val bass = preferences.getInt(bassBoostKey, 0).coerceIn(0, 100)
        val reverb = preferences.getInt(reverbLevelKey, 0).coerceIn(0, 100)

        runCatching {
            bassBoostEffect?.let { effect ->
                if (effect.strengthSupported) effect.setStrength((bass * 10).toShort())
                effect.enabled = enabled && bass > 0
            }
        }
        runCatching {
            environmentalReverbEffect?.let { effect ->
                val level = (-9000 + reverb * 90).toShort()
                effect.setRoomLevel(level)
                effect.setReverbLevel(level)
                effect.enabled = enabled && reverb > 0
            }
        }
        runCatching { equalizerEffect?.enabled = enabled }

        runCatching {
            crossfadeBassBoostEffect?.let { effect ->
                if (effect.strengthSupported) effect.setStrength((bass * 10).toShort())
                effect.enabled = enabled && bass > 0
            }
        }
        runCatching {
            crossfadeReverbEffect?.let { effect ->
                val level = (-9000 + reverb * 90).toShort()
                effect.setRoomLevel(level)
                effect.setReverbLevel(level)
                effect.enabled = enabled && reverb > 0
            }
        }
        runCatching { crossfadeEqualizerEffect?.enabled = enabled }
    }

    private fun releasePlaybackEffects() {
        runCatching { bassBoostEffect?.release() }
        runCatching { environmentalReverbEffect?.release() }
        runCatching { equalizerEffect?.release() }
        runCatching { crossfadeBassBoostEffect?.release() }
        runCatching { crossfadeReverbEffect?.release() }
        runCatching { crossfadeEqualizerEffect?.release() }
        bassBoostEffect = null
        environmentalReverbEffect = null
        equalizerEffect = null
        crossfadeBassBoostEffect = null
        crossfadeReverbEffect = null
        crossfadeEqualizerEffect = null
    }

    private fun sendOpenEqualizerIntent() {
        sendBroadcast(
            Intent(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION).apply {
                putExtra(AudioEffect.EXTRA_AUDIO_SESSION, player.audioSessionId)
                putExtra(AudioEffect.EXTRA_PACKAGE_NAME, packageName)
                putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
            }
        )
    }

    private fun sendCloseEqualizerIntent() {
        sendBroadcast(
            Intent(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION).apply {
                putExtra(AudioEffect.EXTRA_AUDIO_SESSION, player.audioSessionId)
            }
        )
    }

    private fun updatePlaybackState() = coroutineScope.launch {
        playbackStateMutex.withLock {
            withContext(Dispatchers.Main) {
                mediaSession.setPlaybackState(
                    stateBuilder
                        .setState(player.androidPlaybackState, player.currentPosition, 1f)
                        .setBufferedPosition(player.bufferedPosition)
                        .build()
                )
            }
        }
    }

    private val Player.androidPlaybackState: Int
        get() = when (playbackState) {
            Player.STATE_BUFFERING -> if (playWhenReady) PlaybackState.STATE_BUFFERING else PlaybackState.STATE_PAUSED
            Player.STATE_READY -> if (playWhenReady) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED
            Player.STATE_ENDED -> PlaybackState.STATE_STOPPED
            Player.STATE_IDLE -> PlaybackState.STATE_NONE
            else -> PlaybackState.STATE_NONE
        }

    @Suppress("DEPRECATION")
    override fun onEvents(player: Player, events: Player.Events) {
        if (player.duration != C.TIME_UNSET) {
            mediaSession.setMetadata(
                metadataBuilder
                    .putText(MediaMetadata.METADATA_KEY_TITLE, player.mediaMetadata.title)
                    .putText(MediaMetadata.METADATA_KEY_ARTIST, player.mediaMetadata.artist)
                    .putText(MediaMetadata.METADATA_KEY_ALBUM, player.mediaMetadata.albumTitle)
                    .putLong(MediaMetadata.METADATA_KEY_DURATION, player.duration)
                    .build()
            )
        }

        updatePlaybackState()
        if (player.shouldBePlaying && (bassBoostEffect == null || environmentalReverbEffect == null || equalizerEffect == null)) {
            createPlaybackEffects()
        }

        if (events.containsAny(
                Player.EVENT_PLAYBACK_STATE_CHANGED,
                Player.EVENT_PLAY_WHEN_READY_CHANGED,
                Player.EVENT_IS_PLAYING_CHANGED,
                Player.EVENT_POSITION_DISCONTINUITY
            )
        ) {
            val notification = notification()

            if (notification == null) {
                isNotificationStarted = false
                makeInvincible(false)
                stopForeground(false)
                sendCloseEqualizerIntent()
                notificationManager?.cancel(NOTIFICATION_ID)
                return
            }

            if (player.shouldBePlaying && !isNotificationStarted) {
                isNotificationStarted = true
                startForegroundService(this@PlayerService, intent<PlayerService>())
                startForeground(NOTIFICATION_ID, notification)
                makeInvincible(false)
                sendOpenEqualizerIntent()
            } else {
                if (!player.shouldBePlaying) {
                    isNotificationStarted = false
                    stopForeground(false)
                    makeInvincible(true)
                    sendCloseEqualizerIntent()
                }
                notificationManager?.notify(NOTIFICATION_ID, notification)
            }
        }
    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        when (key) {
            persistentQueueKey -> if (sharedPreferences != null) {
                isPersistentQueueEnabled =
                    sharedPreferences.getBoolean(key, isPersistentQueueEnabled)
            }

            volumeNormalizationKey -> maybeNormalizeVolume()

            resumePlaybackWhenDeviceConnectedKey -> maybeResumePlaybackWhenDeviceConnected()

            isInvincibilityEnabledKey -> if (sharedPreferences != null) {
                isInvincibilityEnabled =
                    sharedPreferences.getBoolean(key, isInvincibilityEnabled)
            }

            skipSilenceKey -> if (sharedPreferences != null) {
                player.skipSilenceEnabled = sharedPreferences.getBoolean(key, false)
            }

            playbackSpeedKey, playbackPitchKey -> {
                val speed = preferences.getFloat(playbackSpeedKey, 1f).coerceIn(0.5f, 2f)
                val pitch = preferences.getFloat(playbackPitchKey, 1f).coerceIn(0.7f, 1.3f)
                val parameters = PlaybackParameters(speed, pitch)
                player.setPlaybackParameters(parameters)
                crossfadePlayer?.setPlaybackParameters(parameters)
            }

            audioEffectsEnabledKey, bassBoostKey, reverbLevelKey -> applyPlaybackEffects()

            crossfadeEnabledKey -> {
                if (!preferences.getBoolean(crossfadeEnabledKey, true)) {
                    cancelCrossfade(restoreMainVolume = true)
                } else {
                    ensureCrossfadePlayer()
                }
            }

            isShowingThumbnailInLockscreenKey -> {
                if (sharedPreferences != null) {
                    isShowingThumbnailInLockscreen = sharedPreferences.getBoolean(key, true)
                }
                maybeShowSongCoverInLockScreen()
            }

            trackLoopEnabledKey, queueLoopEnabledKey -> {
                player.repeatMode = when {
                    preferences.getBoolean(trackLoopEnabledKey, false) -> Player.REPEAT_MODE_ONE
                    preferences.getBoolean(queueLoopEnabledKey, false) -> Player.REPEAT_MODE_ALL
                    else -> Player.REPEAT_MODE_OFF
                }
            }
        }
    }

    override fun notification(): Notification? {
        if (player.currentMediaItem == null) return null

        val playIntent = Action.play.pendingIntent
        val pauseIntent = Action.pause.pendingIntent
        val nextIntent = Action.next.pendingIntent
        val prevIntent = Action.previous.pendingIntent

        val mediaMetadata = player.mediaMetadata

        val builder = NotificationCompat.Builder(applicationContext, NOTIFICATION_CHANNEL_ID)
            .setContentTitle(mediaMetadata.title)
            .setContentText(mediaMetadata.artist)
            .setSubText(player.playerError?.message)
            .setLargeIcon(bitmapProvider.bitmap)
            .setAutoCancel(false)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setSmallIcon(player.playerError?.let { R.drawable.alert_circle }
                ?: R.drawable.app_icon)
            .setOngoing(false)
            .setContentIntent(
                activityPendingIntent<MainActivity>(
                    flags = PendingIntent.FLAG_UPDATE_CURRENT
                ) { putExtra("expandPlayerBottomSheet", true) })
            .setDeleteIntent(broadCastPendingIntent<NotificationDismissReceiver>())
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setStyle(
                androidx.media.app.NotificationCompat.MediaStyle()
                    .setShowActionsInCompactView(0, 1, 2)
                    .setMediaSession(MediaSessionCompat.Token.fromToken(mediaSession.sessionToken))
            )
            .addAction(R.drawable.play_skip_back, "Skip back", prevIntent)
            .addAction(
                if (player.shouldBePlaying) R.drawable.pause else R.drawable.play,
                if (player.shouldBePlaying) "Pause" else "Play",
                if (player.shouldBePlaying) pauseIntent else playIntent
            )
            .addAction(R.drawable.play_skip_forward, "Skip forward", nextIntent)

        bitmapProvider.load(mediaMetadata.artworkUri) { bitmap ->
            maybeShowSongCoverInLockScreen()
            notificationManager?.notify(NOTIFICATION_ID, builder.setLargeIcon(bitmap).build())
        }

        return builder.build()
    }

    private fun createNotificationChannel() {
        notificationManager = getSystemService()

        if (!isAtLeastAndroid8) return

        notificationManager?.run {
            if (getNotificationChannel(NOTIFICATION_CHANNEL_ID) == null) {
                createNotificationChannel(
                    NotificationChannel(
                        NOTIFICATION_CHANNEL_ID,
                        getString(R.string.now_playing),
                        NotificationManager.IMPORTANCE_LOW
                    ).apply {
                        setSound(null, null)
                        enableLights(false)
                        enableVibration(false)
                    }
                )
            }

            if (getNotificationChannel(SLEEP_TIMER_NOTIFICATION_CHANNEL_ID) == null) {
                createNotificationChannel(
                    NotificationChannel(
                        SLEEP_TIMER_NOTIFICATION_CHANNEL_ID,
                        getString(R.string.sleep_timer),
                        NotificationManager.IMPORTANCE_LOW
                    ).apply {
                        setSound(null, null)
                        enableLights(false)
                        enableVibration(false)
                    }
                )
            }
        }
    }

    private fun createCacheDataSource(): DataSource.Factory {
        val httpFactory = DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(16000)
            .setReadTimeoutMs(8000)
            .setUserAgent("Mozilla/5.0 (Windows NT 10.0; rv:91.0) Gecko/20100101 Firefox/91.0")

        // DefaultDataSource routes HTTP, content:// and file:// URIs to the
        // correct Android data source. Cache remains enabled for all sources.
        val upstreamFactory = DefaultDataSource.Factory(applicationContext, httpFactory)
        return CacheDataSource.Factory()
            .setCache(cache)
            .setUpstreamDataSourceFactory(upstreamFactory)
    }


    private fun ensureCrossfadePlayer(): ExoPlayer {
        crossfadePlayer?.let { return it }
        val attributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        return ExoPlayer.Builder(this, createRendersFactory(), createMediaSourceFactory())
            .setHandleAudioBecomingNoisy(false)
            .setAudioAttributes(attributes, false)
            .build()
            .also {
                it.volume = 0f
                crossfadePlayer = it
            }
    }

    private fun startCrossfadeMonitor() {
        if (crossfadeMonitorJob?.isActive == true) return
        crossfadeMonitorJob = crossfadeScope.launch {
            while (isActive) {
                val enabled = preferences.getBoolean(crossfadeEnabledKey, true)
                val durationMs = preferences.getInt(crossfadeDurationMsKey, 4000)
                    .coerceIn(2000, 6000).toLong()

                if (enabled && player.isPlaying &&
                    player.playbackState == Player.STATE_READY &&
                    player.repeatMode != Player.REPEAT_MODE_ONE &&
                    crossfadeJob?.isActive != true &&
                    crossfadeSourceId != player.currentMediaItem?.mediaId
                ) {
                    val currentId = player.currentMediaItem?.mediaId
                    val total = player.duration
                    val nextIndex = player.nextMediaItemIndex
                    if (currentId != null &&
                        total > durationMs + 1000L &&
                        player.currentPosition >= total - durationMs &&
                        player.hasNextMediaItem() &&
                        nextIndex != C.INDEX_UNSET &&
                        nextIndex in 0 until player.mediaItemCount
                    ) {
                        val next = player.getMediaItemAt(nextIndex)
                        if (next.mediaId != currentId) {
                            crossfadeSourceId = currentId
                            crossfadeJob = crossfadeScope.launch {
                                runCrossfade(currentId, next, durationMs)
                            }
                        }
                    }
                }
                delay(120)
            }
        }
    }

    private suspend fun runCrossfade(
        sourceId: String,
        nextItem: MediaItem,
        durationMs: Long
    ) {
        val secondary = runCatching { ensureCrossfadePlayer() }.getOrNull() ?: run {
            crossfadeSourceId = null
            return
        }
        val baseVolume = player.volume.coerceIn(0f, 1f)
        crossfadeBaseVolume = baseVolume
        var committed = false

        try {
            if (player.currentMediaItem?.mediaId != sourceId || !player.isPlaying) return

            secondary.pause()
            secondary.stop()
            secondary.clearMediaItems()
            secondary.volume = 0f
            secondary.setPlaybackParameters(player.playbackParameters)
            secondary.setMediaItem(nextItem)
            secondary.prepare()

            val ready = withTimeoutOrNull(4500L) {
                while (secondary.playbackState != Player.STATE_READY) {
                    if (player.currentMediaItem?.mediaId != sourceId || !player.isPlaying) return@withTimeoutOrNull false
                    if (secondary.playbackState == Player.STATE_IDLE || secondary.playerError != null) return@withTimeoutOrNull false
                    delay(60)
                }
                true
            } ?: false

            if (!ready || player.currentMediaItem?.mediaId != sourceId || !player.isPlaying) return

            createCrossfadePlaybackEffects()
            secondary.play()
            val stepMs = 50L
            val steps = (durationMs / stepMs).toInt().coerceAtLeast(1)

            for (step in 1..steps) {
                if (player.currentMediaItem?.mediaId != sourceId || !player.isPlaying) return
                val progress = step.toFloat() / steps.toFloat()
                val angle = progress * (Math.PI / 2.0)
                // Equal-power crossfade: avoids a perceived dip around the midpoint.
                player.volume = (baseVolume * kotlin.math.cos(angle)).toFloat().coerceIn(0f, 1f)
                secondary.volume = kotlin.math.sin(angle).toFloat().coerceIn(0f, 1f)
                delay(stepMs)
            }

            if (player.currentMediaItem?.mediaId != sourceId || !player.isPlaying) return

            committingCrossfade = true
            player.volume = 0f
            player.seekToNextMediaItem()

            val switched = withTimeoutOrNull(7000L) {
                while (
                    player.currentMediaItem?.mediaId != nextItem.mediaId ||
                    player.playbackState != Player.STATE_READY
                ) {
                    if (player.playerError != null) return@withTimeoutOrNull false
                    delay(60)
                }
                true
            } ?: false

            if (switched) {
                val secondaryPosition = secondary.currentPosition.coerceAtLeast(0L)
                val safePosition = secondaryPosition.coerceAtMost(
                    (player.duration - 500L).coerceAtLeast(0L)
                )
                player.seekTo(safePosition)
                player.volume = baseVolume
                secondary.volume = 0f
                secondary.pause()
                secondary.stop()
                secondary.clearMediaItems()
                committed = true
            } else {
                // Main player couldn't switch cleanly. Return volume to it and let
                // its normal queue transition/error recovery continue.
                player.volume = baseVolume
                secondary.volume = 0f
                secondary.pause()
                secondary.stop()
                secondary.clearMediaItems()
            }
        } catch (_: Exception) {
            player.volume = baseVolume
            runCatching {
                secondary.volume = 0f
                secondary.pause()
                secondary.stop()
                secondary.clearMediaItems()
            }
        } finally {
            committingCrossfade = false
            if (!committed && player.currentMediaItem?.mediaId == sourceId) {
                player.volume = baseVolume
            }
            crossfadeSourceId = null
            crossfadeJob = null
        }
    }

    private fun cancelCrossfade(restoreMainVolume: Boolean) {
        val wasActive = crossfadeJob?.isActive == true
        crossfadeJob?.cancel()
        crossfadeJob = null
        crossfadeSourceId = null
        committingCrossfade = false
        crossfadePlayer?.let { secondary ->
            runCatching {
                secondary.volume = 0f
                secondary.pause()
                secondary.stop()
                secondary.clearMediaItems()
            }
        }
        if (restoreMainVolume && wasActive) player.volume = crossfadeBaseVolume.coerceIn(0f, 1f)
    }

    private fun createDataSourceFactory(): DataSource.Factory {
        val chunkLength = 512 * 1024L
        val ringBuffer = RingBuffer<Pair<String, Uri>?>(2) { null }

        return ResolvingDataSource.Factory(createCacheDataSource()) { dataSpec ->
            // Local MediaStore content and app-private file URIs are already playable.
            // Never pass these through the YouTube Innertube resolver.
            if (dataSpec.uri.scheme == "content" || dataSpec.uri.scheme == "file") {
                return@Factory dataSpec
            }
            val videoId = dataSpec.key ?: error("A key must be set")

            if (cache.isCached(videoId, dataSpec.position, chunkLength)) {
                dataSpec
            } else {
                when (videoId) {
                    ringBuffer.getOrNull(0)?.first -> dataSpec.withUri(ringBuffer.getOrNull(0)!!.second)
                    ringBuffer.getOrNull(1)?.first -> dataSpec.withUri(ringBuffer.getOrNull(1)!!.second)
                    else -> {
                        val urlResult = runBlocking(Dispatchers.IO) {
                            Innertube.player(videoId = videoId)
                        }?.mapCatching { body ->
                            if (body.videoDetails?.videoId != videoId) {
                                throw VideoIdMismatchException()
                            }

                            when (val status = body.playabilityStatus?.status) {
                                "OK" -> body.streamingData?.highestQualityFormat?.let { format ->
                                    val mediaItem = runBlocking(Dispatchers.Main) {
                                        player.findNextMediaItemById(videoId)
                                    }

                                    if (mediaItem?.mediaMetadata?.extras?.getString("durationText") == null) {
                                        format.approxDurationMs?.div(1000)
                                            ?.let(DateUtils::formatElapsedTime)?.removePrefix("0")
                                            ?.let { durationText ->
                                                mediaItem?.mediaMetadata?.extras?.putString(
                                                    "durationText",
                                                    durationText
                                                )
                                                database.updateDurationText(videoId, durationText)
                                            }
                                    }

                                    database.query {
                                        mediaItem?.let(database::insert)

                                        database.insert(
                                            Format(
                                                songId = videoId,
                                                itag = format.itag,
                                                mimeType = format.mimeType,
                                                bitrate = format.bitrate,
                                                loudnessDb = body.playerConfig?.audioConfig?.normalizedLoudnessDb,
                                                contentLength = format.contentLength,
                                                lastModified = format.lastModified
                                            )
                                        )
                                    }

                                    format.url
                                } ?: throw PlayableFormatNotFoundException()

                                "UNPLAYABLE" -> throw UnplayableException()
                                "LOGIN_REQUIRED" -> throw LoginRequiredException()
                                else -> throw PlaybackException(
                                    status,
                                    null,
                                    PlaybackException.ERROR_CODE_REMOTE_ERROR
                                )
                            }
                        }

                        urlResult?.getOrThrow()?.let { url ->
                            ringBuffer.append(videoId to url.toUri())
                            dataSpec.withUri(url.toUri())
                                .subrange(dataSpec.uriPositionOffset, chunkLength)
                        } ?: throw PlaybackException(
                            null,
                            urlResult?.exceptionOrNull(),
                            PlaybackException.ERROR_CODE_REMOTE_ERROR
                        )
                    }
                }
            }
        }
    }

    private fun createMediaSourceFactory(): MediaSource.Factory {
        return DefaultMediaSourceFactory(createDataSourceFactory(), DefaultExtractorsFactory())
    }

    private fun createRendersFactory(): RenderersFactory {
        val audioSink = DefaultAudioSink.Builder(applicationContext)
            .setAudioOutputProvider(
                AudioTrackAudioOutputProvider.Builder(applicationContext).build()
            )
            .setAudioProcessorChain(
                DefaultAudioProcessorChain(
                    emptyArray(),
                    SilenceSkippingAudioProcessor(2_000_000, 0.01f, 2_000_000, 0, 256),
                    SonicAudioProcessor()
                )
            )
            .build()

        return RenderersFactory { handler: Handler?, _, audioListener: AudioRendererEventListener?, _, _ ->
            arrayOf(
                MediaCodecAudioRenderer(
                    this,
                    MediaCodecSelector.DEFAULT,
                    handler,
                    audioListener,
                    audioSink
                )
            )
        }
    }

    inner class Binder : AndroidBinder() {
        val player: ExoPlayer
            get() = this@PlayerService.player

        val cache: Cache
            get() = this@PlayerService.cache

        val mediaSession
            get() = this@PlayerService.mediaSession

        fun equalizerBandCount(): Int = runCatching {
            equalizerEffect?.numberOfBands?.toInt() ?: 0
        }.getOrDefault(0)

        fun equalizerBandRange(): IntRange? = runCatching {
            equalizerEffect?.bandLevelRange?.let { range -> range[0].toInt()..range[1].toInt() }
        }.getOrNull()

        fun equalizerBandFrequency(band: Int): Int = runCatching {
            equalizerEffect?.getCenterFreq(band.toShort()) ?: 0
        }.getOrDefault(0)

        fun equalizerBandLevel(band: Int): Int = runCatching {
            equalizerEffect?.getBandLevel(band.toShort())?.toInt() ?: 0
        }.getOrDefault(0)

        fun setEqualizerBandLevel(band: Int, levelMb: Int) {
            runCatching {
                val range = equalizerEffect?.bandLevelRange ?: return
                equalizerEffect?.setBandLevel(
                    band.toShort(),
                    levelMb.coerceIn(range[0].toInt(), range[1].toInt()).toShort()
                )
                val secondaryRange = crossfadeEqualizerEffect?.bandLevelRange
                if (secondaryRange != null && band < crossfadeEqualizerEffect!!.numberOfBands) {
                    crossfadeEqualizerEffect?.setBandLevel(
                        band.toShort(),
                        levelMb.coerceIn(secondaryRange[0].toInt(), secondaryRange[1].toInt()).toShort()
                    )
                }
            }
        }

        fun equalizerPresetNames(): List<String> = runCatching {
            val effect = equalizerEffect ?: return emptyList()
            (0 until effect.numberOfPresets.toInt()).map { effect.getPresetName(it.toShort()) }
        }.getOrDefault(emptyList())

        fun applyEqualizerPreset(index: Int) {
            runCatching {
                val effect = equalizerEffect ?: return
                if (index in 0 until effect.numberOfPresets.toInt()) {
                    effect.usePreset(index.toShort())
                    if (index < (crossfadeEqualizerEffect?.numberOfPresets?.toInt() ?: 0)) {
                        crossfadeEqualizerEffect?.usePreset(index.toShort())
                    }
                }
            }
        }

        val sleepTimerMillisLeft: StateFlow<Long?>?
            get() = timerJob?.millisLeft

        private var radioJob: Job? = null

        var isLoadingRadio by mutableStateOf(false)
            private set

        fun startSleepTimer(delayMillis: Long) {
            timerJob?.cancel()
            if (sleepFadeJob != null) {
                player.volume = sleepFadeOriginalVolume.coerceIn(0f, 1f)
            }
            sleepFadeJob?.cancel()
            sleepFadeOriginalVolume = player.volume
            val fadeDuration = minOf(8_000L, delayMillis.coerceAtLeast(0L))
            sleepFadeJob = coroutineScope.launch(Dispatchers.Main) {
                delay((delayMillis - fadeDuration).coerceAtLeast(0L))
                if (fadeDuration > 0L) {
                    val steps = 24
                    repeat(steps) { step ->
                        player.volume = sleepFadeOriginalVolume * (1f - (step + 1f) / steps)
                        delay((fadeDuration / steps).coerceAtLeast(1L))
                    }
                }
            }

            timerJob = coroutineScope.timer(delayMillis) {
                val notification = NotificationCompat
                    .Builder(this@PlayerService, SLEEP_TIMER_NOTIFICATION_CHANNEL_ID)
                    .setContentTitle(getString(R.string.sleep_timer_ended))
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setAutoCancel(true)
                    .setOnlyAlertOnce(true)
                    .setShowWhen(true)
                    .setSmallIcon(R.drawable.app_icon)
                    .build()

                notificationManager?.notify(SLEEP_TIMER_NOTIFICATION_ID, notification)

                stopSelf()
                exitProcess(0)
            }
        }

        fun cancelSleepTimer() {
            timerJob?.cancel()
            timerJob = null
            val hadFade = sleepFadeJob != null
            sleepFadeJob?.cancel()
            sleepFadeJob = null
            if (hadFade) player.volume = sleepFadeOriginalVolume.coerceIn(0f, 1f)
        }

        fun setupRadio(endpoint: NavigationEndpoint.Endpoint.Watch?) =
            startRadio(endpoint = endpoint, justAdd = true)

        fun playRadio(endpoint: NavigationEndpoint.Endpoint.Watch?) =
            startRadio(endpoint = endpoint, justAdd = false)

        private fun startRadio(endpoint: NavigationEndpoint.Endpoint.Watch?, justAdd: Boolean) {
            radioJob?.cancel()
            radio = null
            YouTubeRadio(
                endpoint?.videoId,
                endpoint?.playlistId,
                endpoint?.playlistSetVideoId,
                endpoint?.params
            ).let {
                isLoadingRadio = true
                radioJob = coroutineScope.launch(Dispatchers.Main) {
                    if (justAdd) {
                        player.addMediaItems(it.process().drop(1))
                    } else {
                        player.forcePlayFromBeginning(it.process())
                    }
                    radio = it
                    isLoadingRadio = false
                }
            }
        }

        fun stopRadio() {
            isLoadingRadio = false
            radioJob?.cancel()
            radio = null
        }

        fun playFromSearch(query: String) {
            coroutineScope.launch {
                Innertube.searchPage(
                    query = query,
                    params = Innertube.SearchFilter.Song.value,
                    fromMusicShelfRendererContent = Innertube.SongItem.Companion::from
                )
            }
        }
    }

    private fun likeAction() = mediaItemState.value?.let { mediaItem ->
        database.query {
            runCatching {
                database.like(
                    songId = mediaItem.mediaId,
                    likedAt = if (isLikedState.value) null else System.currentTimeMillis()
                )
            }
        }
    }

    private fun play() {
        if (player.playerError != null) player.prepare()
        else if (player.playbackState == Player.STATE_ENDED) player.seekToDefaultPosition(0)
        else player.play()
    }

    private inner class SessionCallback(private val player: Player) : MediaSession.Callback() {
        override fun onPlay() = play()
        override fun onPause() = player.pause()
        override fun onSkipToPrevious() = runCatching(player::forceSeekToPrevious).let { }
        override fun onSkipToNext() = runCatching(player::forceSeekToNext).let { }
        override fun onSeekTo(pos: Long) = player.seekTo(pos)
        override fun onStop() = player.pause()
        override fun onRewind() = player.seekToDefaultPosition()
        override fun onSkipToQueueItem(id: Long) =
            runCatching { player.seekToDefaultPosition(id.toInt()) }.let { }

        override fun onPlayFromSearch(query: String?, extras: Bundle?) {
            if (query.isNullOrBlank()) return
            binder.playFromSearch(query)
        }

        override fun onCustomAction(action: String, extras: Bundle?) {
            super.onCustomAction(action, extras)
            if (action == FAVORITE_ACTION) likeAction()
        }
    }

    private inner class NotificationActionReceiver(private val player: Player) :
        BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Action.pause.value -> player.pause()
                Action.play.value -> play()
                Action.next.value -> player.forceSeekToNext()
                Action.previous.value -> player.forceSeekToPrevious()
            }
        }
    }

    class NotificationDismissReceiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            context.stopService(context.intent<PlayerService>())
        }
    }

    @JvmInline
    private value class Action(val value: String) {
        context(context: Context)
        val pendingIntent: PendingIntent
            get() = PendingIntent.getBroadcast(
                context,
                100,
                Intent(value).setPackage(context.packageName),
                PendingIntent.FLAG_UPDATE_CURRENT.or(PendingIntent.FLAG_IMMUTABLE)
            )

        companion object {
            val pause = Action("com.github.musicyou.pause")
            val play = Action("com.github.musicyou.play")
            val next = Action("com.github.musicyou.next")
            val previous = Action("com.github.musicyou.previous")
        }
    }

    private companion object {
        const val NOTIFICATION_ID = 1001
        const val NOTIFICATION_CHANNEL_ID = "default_channel_id"

        const val SLEEP_TIMER_NOTIFICATION_ID = 1002
        const val SLEEP_TIMER_NOTIFICATION_CHANNEL_ID = "sleep_timer_channel_id"

        const val FAVORITE_ACTION = "FAVORITE"
    }
}