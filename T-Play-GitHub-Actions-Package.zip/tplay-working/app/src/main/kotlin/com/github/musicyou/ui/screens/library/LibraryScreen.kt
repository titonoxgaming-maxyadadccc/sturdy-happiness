package com.github.musicyou.ui.screens.library

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.QueueMusic
import androidx.compose.material.icons.outlined.Album
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.DownloadForOffline
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.github.musicyou.LocalPlayerPadding
import com.github.musicyou.R
import com.github.musicyou.ui.components.HomeScaffold

private data class LibraryEntry(
    val titleRes: Int,
    val subtitle: String,
    val icon: ImageVector,
    val open: () -> Unit
)

@Composable
fun LibraryScreen(
    openSearch: () -> Unit,
    openSettings: () -> Unit,
    openSongs: () -> Unit,
    openArtists: () -> Unit,
    openAlbums: () -> Unit,
    openPlaylists: () -> Unit,
    openLocalFiles: () -> Unit,
    openDownloads: () -> Unit
) {
    val playerPadding = LocalPlayerPadding.current
    val entries = listOf(
        LibraryEntry(R.string.local_files, "Audio stored on this device", Icons.Outlined.FolderOpen, openLocalFiles),
        LibraryEntry(R.string.downloads, "Offline copies saved inside T Play", Icons.Outlined.DownloadForOffline, openDownloads),
        LibraryEntry(R.string.songs, "Your saved and recently played tracks", Icons.Outlined.MusicNote, openSongs),
        LibraryEntry(R.string.artists, "Artists you follow and listen to", Icons.Outlined.Person, openArtists),
        LibraryEntry(R.string.albums, "Albums and releases", Icons.Outlined.Album, openAlbums),
        LibraryEntry(R.string.playlists, "Your playlists, mixes and favorites", Icons.AutoMirrored.Outlined.QueueMusic, openPlaylists)
    )

    HomeScaffold(
        title = R.string.library,
        openSearch = openSearch,
        openSettings = openSettings,
        content = {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    start = 16.dp,
                    top = 18.dp,
                    end = 16.dp,
                    bottom = 20.dp + playerPadding
                ),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(entries) { entry ->
                    ElevatedCard(
                        onClick = entry.open,
                        modifier = Modifier.fillMaxWidth().height(154.dp),
                        shape = MaterialTheme.shapes.extraLarge,
                        colors = CardDefaults.elevatedCardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                        )
                    ) {
                        androidx.compose.foundation.layout.Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.SpaceBetween,
                            horizontalAlignment = Alignment.Start
                        ) {
                            Icon(
                                imageVector = entry.icon,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.height(30.dp)
                            )
                            androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = stringResource(entry.titleRes),
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = entry.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    )
}
