package com.github.musicyou.enums

enum class AlbumAccentMode {
    Artwork,
    Violet,
    Blue,
    Rose,
    Emerald
}
