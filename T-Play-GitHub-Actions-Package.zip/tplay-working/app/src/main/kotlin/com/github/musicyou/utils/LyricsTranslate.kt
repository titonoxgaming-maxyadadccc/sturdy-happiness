package com.github.musicyou.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Optional line-by-line lyric translation, the same keyless Google endpoint
 * Square uses. Nothing runs until the person picks a language from the lyrics
 * menu. Lines are sent as repeated `q` parameters, never joined, so a line the
 * translator merges or splits can't push every later line out of step.
 */
object LyricsTranslate {
    private const val BASE_URL = "https://clients5.google.com/translate_a/t"
    private const val BATCH_CHARS = 1_200
    private const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/139.0.0.0 Mobile Safari/537.36"

    /**
     * One translation per line of [texts], in order, or null when the endpoint
     * could not be reached at all. A line that came back unchanged is empty,
     * rather than repeating itself under the original.
     */
    suspend fun lines(texts: List<String>, target: String): List<String>? =
        withContext(Dispatchers.IO) {
            val wanted = texts.withIndex().filter { it.value.isNotBlank() }
            if (wanted.isEmpty()) return@withContext null

            val out = arrayOfNulls<String>(texts.size)
            var reached = false

            for (batch in chunked(wanted)) {
                val answers = translate(batch.map { it.value }, target) ?: continue
                reached = true
                batch.forEachIndexed { at, line ->
                    val answer = answers.getOrNull(at).orEmpty()
                    if (answer.isNotBlank() && !answer.equals(line.value, ignoreCase = true)) {
                        out[line.index] = answer
                    }
                }
            }

            if (!reached) null else out.map { it.orEmpty() }
        }

    private fun translate(texts: List<String>, target: String): List<String>? {
        val url = buildString {
            append(BASE_URL)
            append("?client=dict-chrome-ex&sl=auto&tl=").append(encode(target))
            texts.forEach { append("&q=").append(encode(it)) }
        }

        val body = runCatching {
            val connection = URL(url).openConnection() as HttpURLConnection
            try {
                connection.connectTimeout = 8_000
                connection.readTimeout = 10_000
                connection.setRequestProperty("User-Agent", USER_AGENT)
                if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                    connection.inputStream.bufferedReader().use { it.readText() }
                } else null
            } finally {
                connection.disconnect()
            }
        }.getOrNull() ?: return null

        val array = runCatching { JSONArray(body) }.getOrNull() ?: return null
        return (0 until array.length()).map { at ->
            array.optJSONArray(at)?.optString(0).orEmpty()
        }
    }

    private fun chunked(lines: List<IndexedValue<String>>): List<List<IndexedValue<String>>> {
        val batches = mutableListOf<List<IndexedValue<String>>>()
        var batch = mutableListOf<IndexedValue<String>>()
        var length = 0
        for (line in lines) {
            if (batch.isNotEmpty() && length + line.value.length > BATCH_CHARS) {
                batches += batch
                batch = mutableListOf()
                length = 0
            }
            batch += line
            length += line.value.length
        }
        if (batch.isNotEmpty()) batches += batch
        return batches
    }

    private fun encode(value: String): String = URLEncoder.encode(value, "UTF-8")
}
