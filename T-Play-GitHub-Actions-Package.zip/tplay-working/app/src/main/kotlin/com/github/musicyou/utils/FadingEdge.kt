package com.github.musicyou.utils

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer

/**
 * Masks the leading and trailing edges of a scrolling surface so content eases
 * into the app background instead of being cut off by the fixed chrome.
 */
fun Modifier.verticalFadingEdge(fadeFraction: Float = 0.10f) =
    this
        .graphicsLayer(alpha = 0.99f)
        .drawWithContent {
            drawContent()
            val edge = fadeFraction.coerceIn(0.02f, 0.35f)
            drawRect(
                brush = Brush.verticalGradient(
                    colorStops = arrayOf(
                        0.0f to Color.Transparent,
                        edge to Color.Black,
                        (1.0f - edge) to Color.Black,
                        1.0f to Color.Transparent
                    )
                ),
                blendMode = BlendMode.DstIn
            )
        }
