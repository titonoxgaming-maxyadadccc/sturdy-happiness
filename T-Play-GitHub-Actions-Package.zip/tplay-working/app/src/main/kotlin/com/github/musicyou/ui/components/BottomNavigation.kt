package com.github.musicyou.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.github.musicyou.enums.NavigationLabelsVisibility
import com.github.musicyou.ui.navigation.Routes
import com.github.musicyou.ui.navigation.TopDestinations
import com.github.musicyou.utils.homeScreenTabIndexKey
import com.github.musicyou.utils.navigationLabelsVisibilityKey
import com.github.musicyou.utils.rememberPreference
import dev.lelonio.square.ui.glass.LiquidBottomTab
import dev.lelonio.square.ui.glass.LiquidBottomTabs
import dev.lelonio.square.ui.glass.backdrop.Backdrop
import dev.lelonio.square.ui.glass.backdrop.isRenderEffectSupported

/**
 * The tab bar, built the way Square builds it: one glass capsule with the
 * sliding indicator, tabs in Square's order (Home, New, Radio, Library, Search),
 * a 61dp row, 26dp glyphs and 9sp bold labels, the film and "puck" tints of its
 * glass recipe, and the same margins above the navigation bar.
 *
 * The one difference is deliberate: a dark base sits under the film, so the bar
 * stays readable even on phones where the blur is unavailable (Android 11 and
 * older) or while the glass is frozen for scrolling.
 */
@Composable
fun BottomNavigation(navController: NavHostController, backdrop: Backdrop) {
    val entry by navController.currentBackStackEntryAsState()
    val destination = entry?.destination

    val tabs = remember {
        listOf(Routes.Home, Routes.New, Routes.Radio, Routes.Library, Routes.Search)
            .mapNotNull { route -> TopDestinations.list.firstOrNull { it.route == route } }
    }

    val directIndex = tabs.indexOfFirst { item ->
        destination?.hierarchy?.any { it.hasRoute(route = item.route::class) } == true
    }
    val isLibraryChild = destination?.hierarchy?.any { child ->
        child.hasRoute(Routes.Songs::class) ||
            child.hasRoute(Routes.Artists::class) ||
            child.hasRoute(Routes.Albums::class) ||
            child.hasRoute(Routes.Playlists::class)
    } == true
    val activeIndex = when {
        directIndex >= 0 -> directIndex
        isLibraryChild -> tabs.indexOfFirst { it.route == Routes.Library }
        else -> -1
    }

    // The last tab that was actually on screen, held across screens that are
    // not tabs (a playlist, an album) so the indicator never jumps back to Home.
    var lastIndex by remember { mutableIntStateOf(0) }
    if (activeIndex >= 0 && activeIndex != lastIndex) lastIndex = activeIndex
    val selected = if (activeIndex >= 0) activeIndex else lastIndex

    // A stable lambda: LiquidBottomTabs keys its animation state on it.
    val selectedState = rememberUpdatedState(selected)
    val selectedTabIndex = remember { { selectedState.value } }

    var homeScreenTabIndex by rememberPreference(homeScreenTabIndexKey, 0)
    val navigationLabelsVisibility by rememberPreference(
        navigationLabelsVisibilityKey,
        NavigationLabelsVisibility.Visible,
    )

    val scheme = MaterialTheme.colorScheme
    val lightPage = scheme.background.luminance() > 0.5f
    val ink = scheme.onSurface
    val accent = scheme.primary
    val blurAvailable = isRenderEffectSupported()
    // Square's film (white at 12% on dark, 45% on light) over a base that keeps
    // the labels readable whatever is scrolling underneath.
    val film = if (lightPage) Color.White.copy(alpha = 0.45f) else Color.White.copy(alpha = 0.12f)
    val base = if (lightPage) {
        Color.White.copy(alpha = if (blurAvailable) 0.35f else 0.88f)
    } else {
        Color(0xFF14141C).copy(alpha = if (blurAvailable) 0.55f else 0.92f)
    }
    val containerColor = film.compositeOver(base)
    val puck = if (lightPage) Color.Black.copy(alpha = 0.07f) else Color.Black.copy(alpha = 0.32f)

    val openTab: (Int) -> Unit = { index ->
        val item = tabs.getOrNull(index)
        if (item != null && index != activeIndex) {
            homeScreenTabIndex = TopDestinations.list.indexOfFirst { it.route == item.route }.coerceAtLeast(0)
            navController.navigate(item.route) {
                popUpTo(navController.graph.findStartDestination().id)
                launchSingleTop = true
            }
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(start = 16.dp, end = 16.dp, top = 5.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            LiquidBottomTabs(
                selectedTabIndex = selectedTabIndex,
                onTabSelected = openTab,
                backdrop = backdrop,
                tabsCount = tabs.size,
                accentColor = accent,
                containerColor = containerColor,
                height = 61.dp,
                lensDepth = 20.dp,
                indicatorVisible = activeIndex >= 0,
                indicatorColor = puck,
            ) {
                tabs.forEachIndexed { index, item ->
                    val isSelected = activeIndex >= 0 && index == selected
                    LiquidBottomTab(onClick = { openTab(index) }) {
                        Icon(
                            imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                            contentDescription = stringResource(item.resourceId),
                            tint = if (isSelected) accent else ink.copy(alpha = 0.86f),
                            modifier = Modifier.size(26.dp),
                        )
                        if (navigationLabelsVisibility == NavigationLabelsVisibility.Visible ||
                            (navigationLabelsVisibility == NavigationLabelsVisibility.VisibleWhenActive && isSelected)
                        ) {
                            Text(
                                text = stringResource(item.resourceId),
                                color = if (isSelected) accent else ink.copy(alpha = 0.86f),
                                fontSize = 9.sp,
                                lineHeight = 11.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }
        }
    }
}
