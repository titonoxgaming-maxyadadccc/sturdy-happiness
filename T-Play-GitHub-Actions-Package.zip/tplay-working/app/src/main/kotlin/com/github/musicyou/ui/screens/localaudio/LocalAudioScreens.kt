package com.github.musicyou.ui.screens.localaudio

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DownloadForOffline
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import com.github.musicyou.LocalPlayerServiceBinder
import com.github.musicyou.R
import com.github.musicyou.ui.components.HomeScaffold
import com.github.musicyou.utils.forcePlayAtIndex
import com.github.musicyou.utils.toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun requiredAudioPermission(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LocalMusicScreen(
    openDownloads: () -> Unit,
    openSearch: () -> Unit,
    openSettings: () -> Unit
) {
    val context = LocalContext.current
    val binder = LocalPlayerServiceBinder.current
    val scope = rememberCoroutineScope()
    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, requiredAudioPermission()) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var tracks by remember { mutableStateOf<List<LocalAudioTrack>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var savingTrackId by remember { mutableStateOf<String?>(null) }
    var refreshKey by remember { mutableStateOf(0) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        granted = isGranted
        if (!isGranted) context.toast("Audio permission was not granted")
    }

    LaunchedEffect(granted, refreshKey) {
        if (granted) {
            loading = true
            tracks = withContext(Dispatchers.IO) {
                runCatching { LocalAudioRepository.queryDeviceAudio(context) }.getOrDefault(emptyList())
            }
            loading = false
        }
    }

    fun saveTrackInsideApp(track: LocalAudioTrack) {
        if (savingTrackId != null) return
        scope.launch {
            savingTrackId = track.id
            val result = withContext(Dispatchers.IO) {
                runCatching { LocalAudioRepository.savePrivateCopy(context, track) }
            }
            savingTrackId = null
            if (result.isSuccess) {
                context.toast(context.getString(R.string.download_saved))
            } else {
                context.toast(context.getString(R.string.download_failed))
            }
        }
    }

    HomeScaffold(
        title = R.string.local_files,
        openSearch = openSearch,
        openSettings = openSettings,
        floatingActionButton = {}
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("ON THIS DEVICE", style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text("${tracks.size} audio tracks", style = MaterialTheme.typography.titleMedium)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = openDownloads) {
                        Icon(Icons.Outlined.DownloadForOffline, contentDescription = "T Play Downloads")
                    }
                    IconButton(onClick = { refreshKey++ }, enabled = granted && !loading) {
                        Icon(Icons.Outlined.Refresh, contentDescription = "Refresh library")
                    }
                }
            }

            if (!granted) {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                        Column(
                            Modifier.padding(22.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(Icons.Outlined.FolderOpen, contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary)
                            Text(stringResource(R.string.local_music_permission_title),
                                style = MaterialTheme.typography.titleLarge)
                            Text(stringResource(R.string.local_music_permission_text),
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Button(onClick = { permissionLauncher.launch(requiredAudioPermission()) }) {
                                Text(stringResource(R.string.grant_permission))
                            }
                        }
                    }
                }
            } else if (loading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else if (tracks.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(stringResource(R.string.no_local_songs), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(tracks, key = { it.id }) { track ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClick = {
                                        val items = tracks.map(LocalAudioTrack::asMediaItem)
                                        binder?.stopRadio()
                                        binder?.player?.forcePlayAtIndex(items, tracks.indexOf(track))
                                    },
                                    onLongClick = { saveTrackInsideApp(track) }
                                )
                                .padding(horizontal = 8.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Outlined.MusicNote, contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(end = 14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.titleMedium)
                                Text(
                                    listOfNotNull(track.artist, track.durationLabel.takeIf { track.durationMs > 0 })
                                        .joinToString(" • "),
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            if (savingTrackId == track.id) {
                                CircularProgressIndicator(
                                    modifier = Modifier.padding(start = 10.dp),
                                    strokeWidth = 2.dp
                                )
                            } else {
                                IconButton(onClick = { saveTrackInsideApp(track) }) {
                                    Icon(
                                        Icons.Outlined.DownloadForOffline,
                                        contentDescription = stringResource(R.string.save_to_t_play)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DownloadsScreen(
    openSearch: () -> Unit,
    openSettings: () -> Unit
) {
    val context = LocalContext.current
    val binder = LocalPlayerServiceBinder.current
    var tracks by remember { mutableStateOf<List<LocalAudioTrack>>(emptyList()) }
    var refreshKey by remember { mutableStateOf(0) }
    var confirmDelete by remember { mutableStateOf<LocalAudioTrack?>(null) }

    LaunchedEffect(refreshKey) {
        tracks = withContext(Dispatchers.IO) {
            runCatching { LocalAudioRepository.queryPrivateDownloads(context) }.getOrDefault(emptyList())
        }
    }

    if (confirmDelete != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Remove from T Play?") },
            text = { Text("This removes only the private copy stored by TITONOX PLAYER. The original device file is unchanged.") },
            confirmButton = {
                TextButton(onClick = {
                    val item = confirmDelete!!
                    val deleted = LocalAudioRepository.deletePrivateCopy(context, item)
                    confirmDelete = null
                    if (deleted) {
                        context.toast("Removed from T Play Downloads")
                        refreshKey++
                    } else context.toast("Could not remove this download")
                }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } }
        )
    }

    HomeScaffold(title = R.string.downloads, openSearch = openSearch, openSettings = openSettings) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("PRIVATE APP STORAGE", color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Text("${tracks.size} offline tracks", style = MaterialTheme.typography.titleMedium)
                }
                IconButton(onClick = { refreshKey++ }) {
                    Icon(Icons.Outlined.Refresh, contentDescription = "Refresh downloads")
                }
            }
            if (tracks.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text("No offline copies yet. Long-press a Local file to save a private copy inside T Play.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(tracks, key = { it.id }) { track ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClick = {
                                        val items = tracks.map(LocalAudioTrack::asMediaItem)
                                        binder?.stopRadio()
                                        binder?.player?.forcePlayAtIndex(items, tracks.indexOf(track))
                                    },
                                    onLongClick = { confirmDelete = track }
                                )
                                .padding(horizontal = 8.dp, vertical = 13.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Outlined.DownloadForOffline, contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(end = 14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.titleMedium)
                                Text(
                                    listOfNotNull(track.artist, track.durationLabel.takeIf { track.durationMs > 0 })
                                        .joinToString(" • "),
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
