package com.github.musicyou.ui.screens.discovery

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.github.innertube.Innertube
import com.github.innertube.requests.chartShelves
import com.github.innertube.requests.discoveryShelves
import com.github.innertube.requests.moodsAndGenres
import com.github.innertube.requests.newReleaseShelves
import com.github.musicyou.LocalPlayerPadding
import com.github.musicyou.LocalPlayerServiceBinder
import com.github.musicyou.R
import com.github.musicyou.ui.components.HomeScaffold
import com.github.musicyou.utils.asMediaItem
import com.github.musicyou.utils.forcePlayFromBeginning
import com.github.musicyou.utils.thumbnail
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

@Composable
fun NewReleasesScreen(
    openSearch: () -> Unit,
    openSettings: () -> Unit,
    onOpenEntry: (Innertube.DiscoveryEntry) -> Unit,
) {
    var shelves by remember { mutableStateOf<List<Innertube.DiscoveryShelf>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var failed by remember { mutableStateOf(false) }
    var refreshKey by remember { mutableIntStateOf(0) }
    val playerPadding = LocalPlayerPadding.current
    val binder = LocalPlayerServiceBinder.current

    LaunchedEffect(refreshKey) {
        loading = true
        failed = false
        val loaded = withContext(Dispatchers.IO) {
            coroutineScope {
                val releases = async { Innertube.newReleaseShelves().getOrDefault(emptyList()) }
                val charts = async { Innertube.chartShelves().getOrDefault(emptyList()) }
                releases.await() + charts.await()
            }
        }
        shelves = loaded.distinctBy { it.title }
        failed = loaded.isEmpty()
        loading = false
    }

    HomeScaffold(
        title = R.string.new_music,
        openSearch = openSearch,
        openSettings = openSettings,
    ) {
        when {
            loading && shelves.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            failed -> EmptyDiscovery(
                message = "YouTube Music couldn't load new releases right now.",
                retry = { refreshKey++ },
            )
            else -> LazyColumn(
                contentPadding = PaddingValues(top = 10.dp, bottom = 18.dp + playerPadding),
                verticalArrangement = Arrangement.spacedBy(22.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                item {
                    Column(Modifier.padding(horizontal = 20.dp)) {
                        Text("FRESH FROM YOUTUBE MUSIC", color = MaterialTheme.colorScheme.primary, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                        Text("New & noteworthy", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("New releases, trending albums and charts.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                items(shelves) { shelf ->
                    DiscoveryShelfRow(
                        shelf = shelf,
                        onOpenEntry = onOpenEntry,
                        onPlayShelf = { entries ->
                            val songs = entries.mapNotNull { it.song }
                            if (songs.isNotEmpty()) {
                                binder?.stopRadio()
                                binder?.player?.forcePlayFromBeginning(songs.map { it.asMediaItem })
                            }
                        },
                    )
                }
            }
        }
    }
}

@Composable
fun RadioDiscoveryScreen(
    openSearch: () -> Unit,
    openSettings: () -> Unit,
    onOpenMood: (Innertube.MoodItem) -> Unit,
) {
    var groups by remember { mutableStateOf<List<Innertube.MoodCategory>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var failed by remember { mutableStateOf(false) }
    var refreshKey by remember { mutableIntStateOf(0) }
    val playerPadding = LocalPlayerPadding.current

    LaunchedEffect(refreshKey) {
        loading = true
        val result = withContext(Dispatchers.IO) { Innertube.moodsAndGenres() }
        groups = result.getOrDefault(emptyList())
        failed = groups.isEmpty()
        loading = false
    }

    HomeScaffold(
        title = R.string.radio,
        openSearch = openSearch,
        openSettings = openSettings,
    ) {
        when {
            loading && groups.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            failed -> EmptyDiscovery("YouTube Music's moods and genres are unavailable at the moment.") { refreshKey++ }
            else -> LazyColumn(
                contentPadding = PaddingValues(top = 10.dp, bottom = 18.dp + playerPadding),
                verticalArrangement = Arrangement.spacedBy(20.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                item {
                    Column(Modifier.padding(horizontal = 20.dp)) {
                        Text("FIND YOUR FREQUENCY", color = MaterialTheme.colorScheme.primary, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                        Text("Radio, your way", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("Explore YouTube Music stations, moods and genres.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                items(groups) { group ->
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(group.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 20.dp))
                        androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
                            columns = androidx.compose.foundation.lazy.grid.GridCells.Fixed(2),
                            modifier = Modifier.fillMaxWidth().height(((((group.items.size + 1) / 2) * 78) + (((group.items.size + 1) / 2) - 1).coerceAtLeast(0) * 10).dp),
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            userScrollEnabled = false,
                        ) {
                            gridItems(group.items) { mood ->
                                MoodTile(mood = mood, onClick = { onOpenMood(mood) })
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RadioCategoryScreen(
    title: String,
    browseId: String,
    params: String?,
    onOpenEntry: (Innertube.DiscoveryEntry) -> Unit,
    openSearch: () -> Unit,
    openSettings: () -> Unit,
) {
    var shelves by remember(browseId, params) { mutableStateOf<List<Innertube.DiscoveryShelf>>(emptyList()) }
    var loading by remember(browseId, params) { mutableStateOf(true) }
    var failed by remember(browseId, params) { mutableStateOf(false) }
    var refreshKey by remember(browseId, params) { mutableIntStateOf(0) }
    val playerPadding = LocalPlayerPadding.current
    val binder = LocalPlayerServiceBinder.current

    LaunchedEffect(browseId, params, refreshKey) {
        loading = true
        val result = withContext(Dispatchers.IO) { Innertube.discoveryShelves(browseId, params) }
        shelves = result.getOrDefault(emptyList())
        failed = shelves.isEmpty()
        loading = false
    }

    HomeScaffold(title = R.string.radio, openSearch = openSearch, openSettings = openSettings) {
        when {
            loading && shelves.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            failed -> EmptyDiscovery("This YouTube Music station couldn't be loaded.") { refreshKey++ }
            else -> LazyColumn(
                contentPadding = PaddingValues(top = 10.dp, bottom = 18.dp + playerPadding),
                verticalArrangement = Arrangement.spacedBy(22.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                item {
                    Column(Modifier.padding(horizontal = 20.dp)) {
                        Text("YOUTUBE MUSIC RADIO", color = MaterialTheme.colorScheme.primary, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    }
                }
                items(shelves) { shelf ->
                    DiscoveryShelfRow(
                        shelf = shelf,
                        onOpenEntry = onOpenEntry,
                        onPlayShelf = { entries ->
                            val songs = entries.mapNotNull { it.song }
                            if (songs.isNotEmpty()) {
                                binder?.stopRadio()
                                binder?.player?.forcePlayFromBeginning(songs.map { it.asMediaItem })
                            }
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun DiscoveryShelfRow(
    shelf: Innertube.DiscoveryShelf,
    onOpenEntry: (Innertube.DiscoveryEntry) -> Unit,
    onPlayShelf: (List<Innertube.DiscoveryEntry>) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(shelf.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            if (shelf.items.any { it.song != null }) {
                TextButton(onClick = { onPlayShelf(shelf.items) }) {
                    Icon(Icons.Outlined.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                    Text("Play")
                }
            }
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(shelf.items) { entry ->
                DiscoveryCard(entry = entry, onClick = { onOpenEntry(entry) })
            }
        }
    }
}

@Composable
private fun DiscoveryCard(entry: Innertube.DiscoveryEntry, onClick: () -> Unit) {
    Column(
        modifier = Modifier.width(146.dp).clickable(onClick = onClick),
        verticalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        AsyncImage(
            model = entry.thumbnailUrl.thumbnail(480),
            contentDescription = entry.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().height(146.dp).clip(RoundedCornerShape(19.dp)),
        )
        Text(entry.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        entry.subtitle?.takeIf(String::isNotBlank)?.let {
            Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun MoodTile(mood: Innertube.MoodItem, onClick: () -> Unit) {
    val colors = remember(mood.title) {
        val palette = listOf(
            listOf(Color(0xFF563A8A), Color(0xFF24183E)),
            listOf(Color(0xFF8A3D6B), Color(0xFF3B1E35)),
            listOf(Color(0xFF276A79), Color(0xFF15333F)),
            listOf(Color(0xFF876129), Color(0xFF3B2C1C)),
            listOf(Color(0xFF385E9A), Color(0xFF1D2B4A)),
            listOf(Color(0xFF537343), Color(0xFF253A25)),
        )
        palette[(mood.title.hashCode() and Int.MAX_VALUE) % palette.size]
    }
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(78.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = colors.first()),
    ) {
        Box(
            modifier = Modifier.fillMaxSize().background(Brush.linearGradient(colors)),
            contentAlignment = Alignment.CenterStart,
        ) {
            Text(mood.title, modifier = Modifier.padding(horizontal = 14.dp), color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun EmptyDiscovery(message: String, retry: (() -> Unit)? = null) {
    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(message, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        retry?.let { TextButton(onClick = it) { Text("Try again") } }
    }
}

