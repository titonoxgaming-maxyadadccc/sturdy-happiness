package dev.lelonio.square.ui.theme

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Host-app theme bridge required by the vendored Square Liquid Glass renderer. */
val LocalInkOverride = staticCompositionLocalOf<Color?> { null }
val LocalLightTheme = staticCompositionLocalOf { false }
val Ink: Color = Color(0xFFF7F5FF)
