package dev.lelonio.square.ui.player

/** Shared specular rim strength used by the Square Liquid Glass components. */
const val BarHighlightAlpha: Float = 0.30f
