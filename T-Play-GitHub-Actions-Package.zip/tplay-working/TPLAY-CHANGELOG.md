# T Play changelog

## 1.4.0 — Local audio, private downloads and crossfade
- Added Android MediaStore scanning for indexed audio on the device with runtime audio permission.
- Long-press a local device track to copy it directly into TITONOX PLAYER private storage.
- Added an in-app Downloads library; offline copies are stored under the app's private files directory and are not placed in the public Downloads folder.
- Added queue-aware 2-player equal-power crossfade, default ON, with a 2–6 second setting (default 4 seconds).
- Crossfade cancels safely on pause, manual seek, queue edit, shuffle/repeat changes, or disabling the setting.
- Local and app-private file URIs bypass YouTube stream resolution and play through Media3's normal file/content data sources.
- YouTube Music streams are not exported as MP3 files; offline copies are limited to user-selected device audio or other directly accessible files the app is authorized to read.


## 1.3.1 — Branding, live glass settings and scroll polish
- Added creator name and TITONOX OFFICIAL social links to About.
- Updated adaptive launcher mark and TV banner.
- Added top/bottom content fade masks to home/discovery/library and settings scroll surfaces.
- Fixed BottomNavigation overriding the preference-backed Liquid Glass configuration; dock now uses the settings-driven config from MainActivity.



## 1.5.0 — Part 2: visual polish and artwork-aware theming
- Playlist and artist cover artwork now samples a dominant accent and updates the app theme while those pages are active.
- Appearance settings now include artwork/fixed accent modes and Fastest, Balanced, and Quality glass presets; manual sliders remain available.
- Existing horizontally scrollable search categories and directional page transitions are retained.
- Existing artist/playlist navigation, synchronized lyrics, queue, effects, and player controls are preserved.
- This is a source update; compilation and physical-device behavior still require Android SDK/Gradle validation.

## 1.5.1 - Part 3 stability audit
- See PART_3_STABILITY_AUDIT.md (compile fixes, artwork-accent cache, local-library sorting fix, GitHub workflow/.gitignore hardening).

## 1.5.2 - Part 4
- Radio crash fix, Square-style tab bar, redesigned Effects sheet, LrcLib lyrics source, animated lyric lines, lyric translation. See PART_3_STABILITY_AUDIT.md.
